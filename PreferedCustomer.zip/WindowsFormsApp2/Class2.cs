﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class Customer: Person
    {
        int _customerNumber;
        bool _mailing;

        //create customerNumber property
        public int customerNumber
        {
            get
            {
                return _customerNumber;
            }
            set
            {
                _customerNumber = value;
            }
        }
        //create Mailing property
        public bool Mailing
        {
            get
            {
                return _mailing;
            }
            set
            {
                _mailing = value;
            }
        }
    }
}
