﻿namespace Stadium_Seating_Form
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_CCSold = new System.Windows.Forms.TextBox();
            this.txt_CBSold = new System.Windows.Forms.TextBox();
            this.txt_CASold = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_totalRev = new System.Windows.Forms.TextBox();
            this.txt_CCRev = new System.Windows.Forms.TextBox();
            this.txt_CBRev = new System.Windows.Forms.TextBox();
            this.txt_CARev = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_CalRev = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_CCSold);
            this.groupBox1.Controls.Add(this.txt_CBSold);
            this.groupBox1.Controls.Add(this.txt_CASold);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(12, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(243, 229);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ticket Sold";
            // 
            // txt_CCSold
            // 
            this.txt_CCSold.Location = new System.Drawing.Point(73, 172);
            this.txt_CCSold.Name = "txt_CCSold";
            this.txt_CCSold.Size = new System.Drawing.Size(100, 20);
            this.txt_CCSold.TabIndex = 11;
            // 
            // txt_CBSold
            // 
            this.txt_CBSold.Location = new System.Drawing.Point(73, 129);
            this.txt_CBSold.Name = "txt_CBSold";
            this.txt_CBSold.Size = new System.Drawing.Size(100, 20);
            this.txt_CBSold.TabIndex = 10;
            // 
            // txt_CASold
            // 
            this.txt_CASold.Location = new System.Drawing.Point(73, 82);
            this.txt_CASold.Name = "txt_CASold";
            this.txt_CASold.Size = new System.Drawing.Size(100, 20);
            this.txt_CASold.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(23, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter the number of tickets sold for each class of seats";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Class A:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Class B:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Class C:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_totalRev);
            this.groupBox2.Controls.Add(this.txt_CCRev);
            this.groupBox2.Controls.Add(this.txt_CBRev);
            this.groupBox2.Controls.Add(this.txt_CARev);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(274, 29);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(230, 229);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Revenue Generated";
            // 
            // txt_totalRev
            // 
            this.txt_totalRev.Location = new System.Drawing.Point(76, 192);
            this.txt_totalRev.Name = "txt_totalRev";
            this.txt_totalRev.ReadOnly = true;
            this.txt_totalRev.Size = new System.Drawing.Size(100, 20);
            this.txt_totalRev.TabIndex = 15;
            // 
            // txt_CCRev
            // 
            this.txt_CCRev.Location = new System.Drawing.Point(76, 154);
            this.txt_CCRev.Name = "txt_CCRev";
            this.txt_CCRev.ReadOnly = true;
            this.txt_CCRev.Size = new System.Drawing.Size(100, 20);
            this.txt_CCRev.TabIndex = 14;
            // 
            // txt_CBRev
            // 
            this.txt_CBRev.Location = new System.Drawing.Point(76, 111);
            this.txt_CBRev.Name = "txt_CBRev";
            this.txt_CBRev.ReadOnly = true;
            this.txt_CBRev.Size = new System.Drawing.Size(100, 20);
            this.txt_CBRev.TabIndex = 13;
            // 
            // txt_CARev
            // 
            this.txt_CARev.Location = new System.Drawing.Point(76, 63);
            this.txt_CARev.Name = "txt_CARev";
            this.txt_CARev.ReadOnly = true;
            this.txt_CARev.Size = new System.Drawing.Size(100, 20);
            this.txt_CARev.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 195);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Total:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Class C:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Class B:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Class A:";
            // 
            // btn_CalRev
            // 
            this.btn_CalRev.Location = new System.Drawing.Point(105, 267);
            this.btn_CalRev.Name = "btn_CalRev";
            this.btn_CalRev.Size = new System.Drawing.Size(80, 43);
            this.btn_CalRev.TabIndex = 1;
            this.btn_CalRev.Text = "Calculate Revenue";
            this.btn_CalRev.UseVisualStyleBackColor = true;
            this.btn_CalRev.Click += new System.EventHandler(this.btn_CalRev_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.Location = new System.Drawing.Point(211, 267);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(77, 43);
            this.btn_Clear.TabIndex = 2;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(313, 267);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(74, 43);
            this.btn_Exit.TabIndex = 3;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 322);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_CalRev);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Stadium Seating";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_CCSold;
        private System.Windows.Forms.TextBox txt_CBSold;
        private System.Windows.Forms.TextBox txt_CASold;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_totalRev;
        private System.Windows.Forms.TextBox txt_CCRev;
        private System.Windows.Forms.TextBox txt_CBRev;
        private System.Windows.Forms.TextBox txt_CARev;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_CalRev;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_Exit;
    }
}

