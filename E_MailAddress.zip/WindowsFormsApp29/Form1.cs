﻿using System;

using System.Collections.Generic;

using System.ComponentModel;

using System.Data;

using System.Drawing;

using System.Linq;

using System.Text;

using System.Windows.Forms;

using System.IO;

namespace persons

{



    public partial class Form1 : Form

    {

        public static string pname;

        public static string pemail;

        public static string pphnum;

        List<PersonEntry> personsList = new List<PersonEntry>();

        public Form1()

        {

            InitializeComponent();

        }

        //Form load event

        private void Form1_Load(object sender, EventArgs e)

        {

            try

            {   // Opening file using a stream reader

                using (StreamReader sr = new StreamReader("PersonList.txt"))

                {

                    String line;



                    // Reading data from file

                    while ((line = sr.ReadLine()) != null)

                    {

                        //Creating person object

                        PersonEntry obj = new PersonEntry(line.Split()[0], line.Split()[1], line.Split()[2]);



                        //Adding names to list box

                        lbNames.Items.Add(obj.getName());

                        //Adding objects to list

                        personsList.Add(obj);

                    }

                }

            }

            catch (Exception ex)

            {

                //Handling exceptions

                MessageBox.Show("The file could not be read:");

                MessageBox.Show(ex.Message);

            }

        }

        //List box selected index changed eevnt

        private void lbNames_SelectedIndexChanged(object sender, EventArgs e)

        {

            //Getting selected item

            string selected = lbNames.SelectedItem.ToString();

            //Iterating over objects in list

            foreach (PersonEntry person in personsList)

            {

                //Searching for selected name

                if (person.getName().Equals(selected))

                {

                    //Filling global variables

                    pname = person.getName();

                    pemail = person.getEmail();

                    pphnum = person.getPhnum();

                }

            }

            //Opening new form

            details frm2 = new details();

            frm2.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    //Class definition

    class PersonEntry

    {

        //Member variables

        private string name;

        private string email;

        private string phnum;

        //Constructor

        public PersonEntry(string name, string email, string phnum)

        {

            this.name = name;

            this.email = email;

            this.phnum = phnum;

        }

        //Getter method for name

        public string getName()

        {

            return this.name;

        }

        //Getter method for email

        public string getEmail()

        {

            return this.email;

        }

        //Getter method for phone number

        public string getPhnum()

        {

            return this.phnum;

        }

    }

}