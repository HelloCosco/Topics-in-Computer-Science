﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Create_Click(object sender, EventArgs e)
        {

            //object create for customer class
            Customer objcustomer = new Customer();

            //set the properties for customer class
            SetCustomerData(objcustomer);

            //display the customer object properties
            lbl_pName.Text = objcustomer.Name;
            lbl_pAddress.Text = objcustomer.Address;
            lbl_pPhoneNO.Text = objcustomer.PhoneNumber;
            lbl_cusNumber.Text = objcustomer.customerNumber.ToString();
            lbl_mailing.Text = objcustomer.Mailing.ToString();

            //set the appearance of the label control
            setLabelAppearance();

            

        }

        private void SetCustomerData(Customer objcustomer)
        {
            int customerNumber;
            bool mailing;

            //checks person's Name is empty or not
            if (txt_pName.Text != "")
            {
                objcustomer.Name = txt_pName.Text;
            }
            else
            {
                MessageBox.Show("Please enter the person's name");
            }

            //checks Person's address is empty or not
            if (txt_pAddress.Text != "")
            {
                objcustomer.Address = txt_pAddress.Text;
            }
            else
            {
                MessageBox.Show("Please enter the person's Address");
            }

            //checks person's phone number is empty or not
            if (txt_pPhoneNO.Text != "")
            {
                objcustomer.PhoneNumber = txt_pPhoneNO.Text;
            }

            else
            {
                MessageBox.Show("Please enter the person's phone number");
            }

            //checks customer number is typed numerical or not
            if (int.TryParse(txt_cusNumber.Text, out customerNumber))
            {
                objcustomer.customerNumber = customerNumber;
            }

            else
            {
                MessageBox.Show("Invalid customer number");
            }

            //checks mailing type is boolean or not
            if (bool.TryParse(chk_Mailing.Checked.ToString(), out mailing))
            {
                objcustomer.Mailing = mailing;
            }
            else
            {
                MessageBox.Show("Invalid mailing");
            }
        }
        private void setLabelAppearance()
        {
            //change the fore color of a label control
            lbl_pName.ForeColor = Color.Tomato;
            lbl_pAddress.ForeColor = Color.Tomato;
            lbl_pPhoneNO.ForeColor = Color.Tomato;
            lbl_cusNumber.ForeColor = Color.Tomato;
            lbl_mailing.ForeColor = Color.Tomato;

            //change the border style of a label control
            lbl_pName.BorderStyle = BorderStyle.FixedSingle;
            lbl_pAddress.BorderStyle = BorderStyle.FixedSingle;
            lbl_pPhoneNO.BorderStyle = BorderStyle.FixedSingle;
            lbl_cusNumber.BorderStyle = BorderStyle.FixedSingle;
            lbl_mailing.BorderStyle = BorderStyle.FixedSingle;

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}
        