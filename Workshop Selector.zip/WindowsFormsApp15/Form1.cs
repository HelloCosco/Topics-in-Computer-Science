﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int workshop = 0;
            int location = 0;
            int days = 0;
            double regFee = 0.00, lodFee = 0.00, totalFee = 0.00;

            workshop = listBox1.SelectedIndex;
            location = listBox2.SelectedIndex;

            switch (workshop)
            {
                case 0:
                    regFee = 1000.00;
                    days = 3;
                    break;

                case 1:
                    regFee = 800.00;
                    days = 3;
                    break;

                case 2:
                    regFee = 1500.00;
                    days = 3;
                    break;

                case 3:
                    regFee = 1300.00;
                    days = 5;
                    break;

                case 4:
                    regFee = 500.00;
                    days = 1;
                    break;
            }
            switch (location)
            {
                case 0:
                    lodFee = days * 150.00;
                    break;

                case 1:
                    lodFee = days * 225.00;
                    break;

                case 2:
                    lodFee = days * 175.00;
                    break;

                case 3:
                    lodFee = days * 300.00;
                    break;

                case 4:
                    lodFee = days * 175.00;
                    break;

                case 5:
                    lodFee = days * 150.00;
                    break;
            }

            totalFee = (regFee + lodFee);

            textBox1.Text = regFee.ToString();
            textBox2.Text = lodFee.ToString();

            textBox3.Text = totalFee.ToString();




        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
            listBox2.ClearSelected();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();



        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
