﻿namespace WindowsFormsApp23
{
    partial class drinkVendingMachine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(drinkVendingMachine));
            this.colaGroupBox = new System.Windows.Forms.GroupBox();
            this.colaTextBox = new System.Windows.Forms.TextBox();
            this.colaPriceLabel = new System.Windows.Forms.Label();
            this.colaLeftLabel = new System.Windows.Forms.Label();
            this.colaPictureBox = new System.Windows.Forms.PictureBox();
            this.rootBeerGroupBox = new System.Windows.Forms.GroupBox();
            this.rootBeerTextBox = new System.Windows.Forms.TextBox();
            this.rootBeerLeftLabel = new System.Windows.Forms.Label();
            this.rootBeerPriceLabel = new System.Windows.Forms.Label();
            this.rootBeerPictureBox = new System.Windows.Forms.PictureBox();
            this.leonLimeGroupBox = new System.Windows.Forms.GroupBox();
            this.lemonLimeTextBox = new System.Windows.Forms.TextBox();
            this.lemonLimeLeftLabel = new System.Windows.Forms.Label();
            this.lemonLimePriceLabel = new System.Windows.Forms.Label();
            this.lemonLimePictureBox = new System.Windows.Forms.PictureBox();
            this.grapeSodeGroupBox = new System.Windows.Forms.GroupBox();
            this.grapeSodaTextBox = new System.Windows.Forms.TextBox();
            this.grapeSodaleftLabel = new System.Windows.Forms.Label();
            this.grapeSodaPriceLabel = new System.Windows.Forms.Label();
            this.grapesodaPictureBox = new System.Windows.Forms.PictureBox();
            this.creamSodaGroupBox = new System.Windows.Forms.GroupBox();
            this.creamSodaTextBox = new System.Windows.Forms.TextBox();
            this.creamSodaLeftLabel = new System.Windows.Forms.Label();
            this.creamSodaPriceLabel = new System.Windows.Forms.Label();
            this.creamSodaPictureBox = new System.Windows.Forms.PictureBox();
            this.totalGroupBox = new System.Windows.Forms.GroupBox();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.totalLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.selectLabel = new System.Windows.Forms.Label();
            this.colaGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colaPictureBox)).BeginInit();
            this.rootBeerGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rootBeerPictureBox)).BeginInit();
            this.leonLimeGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lemonLimePictureBox)).BeginInit();
            this.grapeSodeGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grapesodaPictureBox)).BeginInit();
            this.creamSodaGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.creamSodaPictureBox)).BeginInit();
            this.totalGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // colaGroupBox
            // 
            this.colaGroupBox.Controls.Add(this.colaTextBox);
            this.colaGroupBox.Controls.Add(this.colaPriceLabel);
            this.colaGroupBox.Controls.Add(this.colaLeftLabel);
            this.colaGroupBox.Controls.Add(this.colaPictureBox);
            this.colaGroupBox.Location = new System.Drawing.Point(12, 43);
            this.colaGroupBox.Name = "colaGroupBox";
            this.colaGroupBox.Size = new System.Drawing.Size(266, 131);
            this.colaGroupBox.TabIndex = 0;
            this.colaGroupBox.TabStop = false;
            this.colaGroupBox.Text = "groupBox1";
            // 
            // colaTextBox
            // 
            this.colaTextBox.Location = new System.Drawing.Point(183, 75);
            this.colaTextBox.Multiline = true;
            this.colaTextBox.Name = "colaTextBox";
            this.colaTextBox.Size = new System.Drawing.Size(66, 41);
            this.colaTextBox.TabIndex = 16;
            // 
            // colaPriceLabel
            // 
            this.colaPriceLabel.AutoSize = true;
            this.colaPriceLabel.Location = new System.Drawing.Point(180, 59);
            this.colaPriceLabel.Name = "colaPriceLabel";
            this.colaPriceLabel.Size = new System.Drawing.Size(61, 13);
            this.colaPriceLabel.TabIndex = 10;
            this.colaPriceLabel.Text = "Drinks Left:";
            // 
            // colaLeftLabel
            // 
            this.colaLeftLabel.AutoSize = true;
            this.colaLeftLabel.Location = new System.Drawing.Point(188, 19);
            this.colaLeftLabel.Name = "colaLeftLabel";
            this.colaLeftLabel.Size = new System.Drawing.Size(37, 13);
            this.colaLeftLabel.TabIndex = 4;
            this.colaLeftLabel.Text = "$ 0.00";
            // 
            // colaPictureBox
            // 
            this.colaPictureBox.Image = global::WindowsFormsApp23.Properties.Resources.Cola;
            this.colaPictureBox.Location = new System.Drawing.Point(6, 19);
            this.colaPictureBox.Name = "colaPictureBox";
            this.colaPictureBox.Size = new System.Drawing.Size(122, 112);
            this.colaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.colaPictureBox.TabIndex = 4;
            this.colaPictureBox.TabStop = false;
            this.colaPictureBox.Click += new System.EventHandler(this.colaPictureBox_Click);
            // 
            // rootBeerGroupBox
            // 
            this.rootBeerGroupBox.Controls.Add(this.rootBeerTextBox);
            this.rootBeerGroupBox.Controls.Add(this.rootBeerLeftLabel);
            this.rootBeerGroupBox.Controls.Add(this.rootBeerPriceLabel);
            this.rootBeerGroupBox.Controls.Add(this.rootBeerPictureBox);
            this.rootBeerGroupBox.Location = new System.Drawing.Point(302, 43);
            this.rootBeerGroupBox.Name = "rootBeerGroupBox";
            this.rootBeerGroupBox.Size = new System.Drawing.Size(262, 131);
            this.rootBeerGroupBox.TabIndex = 0;
            this.rootBeerGroupBox.TabStop = false;
            this.rootBeerGroupBox.Text = "groupBox2";
            // 
            // rootBeerTextBox
            // 
            this.rootBeerTextBox.Location = new System.Drawing.Point(174, 75);
            this.rootBeerTextBox.Multiline = true;
            this.rootBeerTextBox.Name = "rootBeerTextBox";
            this.rootBeerTextBox.Size = new System.Drawing.Size(69, 41);
            this.rootBeerTextBox.TabIndex = 17;
            // 
            // rootBeerLeftLabel
            // 
            this.rootBeerLeftLabel.AutoSize = true;
            this.rootBeerLeftLabel.Location = new System.Drawing.Point(171, 59);
            this.rootBeerLeftLabel.Name = "rootBeerLeftLabel";
            this.rootBeerLeftLabel.Size = new System.Drawing.Size(61, 13);
            this.rootBeerLeftLabel.TabIndex = 11;
            this.rootBeerLeftLabel.Text = "Drinks Left:";
            // 
            // rootBeerPriceLabel
            // 
            this.rootBeerPriceLabel.AutoSize = true;
            this.rootBeerPriceLabel.Location = new System.Drawing.Point(182, 19);
            this.rootBeerPriceLabel.Name = "rootBeerPriceLabel";
            this.rootBeerPriceLabel.Size = new System.Drawing.Size(37, 13);
            this.rootBeerPriceLabel.TabIndex = 5;
            this.rootBeerPriceLabel.Text = "$ 0.00";
            // 
            // rootBeerPictureBox
            // 
            this.rootBeerPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("rootBeerPictureBox.Image")));
            this.rootBeerPictureBox.Location = new System.Drawing.Point(6, 19);
            this.rootBeerPictureBox.Name = "rootBeerPictureBox";
            this.rootBeerPictureBox.Size = new System.Drawing.Size(115, 106);
            this.rootBeerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rootBeerPictureBox.TabIndex = 5;
            this.rootBeerPictureBox.TabStop = false;
            this.rootBeerPictureBox.Click += new System.EventHandler(this.rootBeerPictureBox_Click);
            // 
            // leonLimeGroupBox
            // 
            this.leonLimeGroupBox.Controls.Add(this.lemonLimeTextBox);
            this.leonLimeGroupBox.Controls.Add(this.lemonLimeLeftLabel);
            this.leonLimeGroupBox.Controls.Add(this.lemonLimePriceLabel);
            this.leonLimeGroupBox.Controls.Add(this.lemonLimePictureBox);
            this.leonLimeGroupBox.Location = new System.Drawing.Point(12, 180);
            this.leonLimeGroupBox.Name = "leonLimeGroupBox";
            this.leonLimeGroupBox.Size = new System.Drawing.Size(266, 126);
            this.leonLimeGroupBox.TabIndex = 0;
            this.leonLimeGroupBox.TabStop = false;
            this.leonLimeGroupBox.Text = "groupBox3";
            // 
            // lemonLimeTextBox
            // 
            this.lemonLimeTextBox.Location = new System.Drawing.Point(183, 74);
            this.lemonLimeTextBox.Multiline = true;
            this.lemonLimeTextBox.Name = "lemonLimeTextBox";
            this.lemonLimeTextBox.Size = new System.Drawing.Size(66, 35);
            this.lemonLimeTextBox.TabIndex = 4;
            // 
            // lemonLimeLeftLabel
            // 
            this.lemonLimeLeftLabel.AutoSize = true;
            this.lemonLimeLeftLabel.Location = new System.Drawing.Point(180, 58);
            this.lemonLimeLeftLabel.Name = "lemonLimeLeftLabel";
            this.lemonLimeLeftLabel.Size = new System.Drawing.Size(61, 13);
            this.lemonLimeLeftLabel.TabIndex = 12;
            this.lemonLimeLeftLabel.Text = "Drinks Left:";
            // 
            // lemonLimePriceLabel
            // 
            this.lemonLimePriceLabel.AutoSize = true;
            this.lemonLimePriceLabel.Location = new System.Drawing.Point(188, 19);
            this.lemonLimePriceLabel.Name = "lemonLimePriceLabel";
            this.lemonLimePriceLabel.Size = new System.Drawing.Size(37, 13);
            this.lemonLimePriceLabel.TabIndex = 6;
            this.lemonLimePriceLabel.Text = "$ 0.00";
            // 
            // lemonLimePictureBox
            // 
            this.lemonLimePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("lemonLimePictureBox.Image")));
            this.lemonLimePictureBox.Location = new System.Drawing.Point(6, 19);
            this.lemonLimePictureBox.Name = "lemonLimePictureBox";
            this.lemonLimePictureBox.Size = new System.Drawing.Size(122, 106);
            this.lemonLimePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lemonLimePictureBox.TabIndex = 6;
            this.lemonLimePictureBox.TabStop = false;
            this.lemonLimePictureBox.Click += new System.EventHandler(this.lemonLimePictureBox_Click);
            // 
            // grapeSodeGroupBox
            // 
            this.grapeSodeGroupBox.Controls.Add(this.grapeSodaTextBox);
            this.grapeSodeGroupBox.Controls.Add(this.grapeSodaleftLabel);
            this.grapeSodeGroupBox.Controls.Add(this.grapeSodaPriceLabel);
            this.grapeSodeGroupBox.Controls.Add(this.grapesodaPictureBox);
            this.grapeSodeGroupBox.Location = new System.Drawing.Point(302, 180);
            this.grapeSodeGroupBox.Name = "grapeSodeGroupBox";
            this.grapeSodeGroupBox.Size = new System.Drawing.Size(262, 126);
            this.grapeSodeGroupBox.TabIndex = 0;
            this.grapeSodeGroupBox.TabStop = false;
            this.grapeSodeGroupBox.Text = "groupBox4";
            // 
            // grapeSodaTextBox
            // 
            this.grapeSodaTextBox.Location = new System.Drawing.Point(174, 69);
            this.grapeSodaTextBox.Multiline = true;
            this.grapeSodaTextBox.Name = "grapeSodaTextBox";
            this.grapeSodaTextBox.Size = new System.Drawing.Size(69, 35);
            this.grapeSodaTextBox.TabIndex = 13;
            // 
            // grapeSodaleftLabel
            // 
            this.grapeSodaleftLabel.AutoSize = true;
            this.grapeSodaleftLabel.Location = new System.Drawing.Point(171, 53);
            this.grapeSodaleftLabel.Name = "grapeSodaleftLabel";
            this.grapeSodaleftLabel.Size = new System.Drawing.Size(61, 13);
            this.grapeSodaleftLabel.TabIndex = 13;
            this.grapeSodaleftLabel.Text = "Drinks Left:";
            // 
            // grapeSodaPriceLabel
            // 
            this.grapeSodaPriceLabel.AutoSize = true;
            this.grapeSodaPriceLabel.Location = new System.Drawing.Point(182, 19);
            this.grapeSodaPriceLabel.Name = "grapeSodaPriceLabel";
            this.grapeSodaPriceLabel.Size = new System.Drawing.Size(37, 13);
            this.grapeSodaPriceLabel.TabIndex = 7;
            this.grapeSodaPriceLabel.Text = "$ 0.00";
            // 
            // grapesodaPictureBox
            // 
            this.grapesodaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("grapesodaPictureBox.Image")));
            this.grapesodaPictureBox.Location = new System.Drawing.Point(6, 19);
            this.grapesodaPictureBox.Name = "grapesodaPictureBox";
            this.grapesodaPictureBox.Size = new System.Drawing.Size(115, 101);
            this.grapesodaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.grapesodaPictureBox.TabIndex = 7;
            this.grapesodaPictureBox.TabStop = false;
            this.grapesodaPictureBox.Click += new System.EventHandler(this.grapesodaPictureBox_Click);
            // 
            // creamSodaGroupBox
            // 
            this.creamSodaGroupBox.Controls.Add(this.creamSodaTextBox);
            this.creamSodaGroupBox.Controls.Add(this.creamSodaLeftLabel);
            this.creamSodaGroupBox.Controls.Add(this.creamSodaPriceLabel);
            this.creamSodaGroupBox.Controls.Add(this.creamSodaPictureBox);
            this.creamSodaGroupBox.Location = new System.Drawing.Point(12, 312);
            this.creamSodaGroupBox.Name = "creamSodaGroupBox";
            this.creamSodaGroupBox.Size = new System.Drawing.Size(266, 139);
            this.creamSodaGroupBox.TabIndex = 0;
            this.creamSodaGroupBox.TabStop = false;
            this.creamSodaGroupBox.Text = "groupBox5";
            // 
            // creamSodaTextBox
            // 
            this.creamSodaTextBox.Location = new System.Drawing.Point(183, 71);
            this.creamSodaTextBox.Multiline = true;
            this.creamSodaTextBox.Name = "creamSodaTextBox";
            this.creamSodaTextBox.Size = new System.Drawing.Size(66, 33);
            this.creamSodaTextBox.TabIndex = 14;
            // 
            // creamSodaLeftLabel
            // 
            this.creamSodaLeftLabel.AutoSize = true;
            this.creamSodaLeftLabel.Location = new System.Drawing.Point(180, 55);
            this.creamSodaLeftLabel.Name = "creamSodaLeftLabel";
            this.creamSodaLeftLabel.Size = new System.Drawing.Size(61, 13);
            this.creamSodaLeftLabel.TabIndex = 14;
            this.creamSodaLeftLabel.Text = "Drinks Left:";
            // 
            // creamSodaPriceLabel
            // 
            this.creamSodaPriceLabel.AutoSize = true;
            this.creamSodaPriceLabel.Location = new System.Drawing.Point(188, 16);
            this.creamSodaPriceLabel.Name = "creamSodaPriceLabel";
            this.creamSodaPriceLabel.Size = new System.Drawing.Size(37, 13);
            this.creamSodaPriceLabel.TabIndex = 8;
            this.creamSodaPriceLabel.Text = "$ 0.00";
            // 
            // creamSodaPictureBox
            // 
            this.creamSodaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("creamSodaPictureBox.Image")));
            this.creamSodaPictureBox.Location = new System.Drawing.Point(6, 19);
            this.creamSodaPictureBox.Name = "creamSodaPictureBox";
            this.creamSodaPictureBox.Size = new System.Drawing.Size(122, 114);
            this.creamSodaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.creamSodaPictureBox.TabIndex = 8;
            this.creamSodaPictureBox.TabStop = false;
            this.creamSodaPictureBox.Click += new System.EventHandler(this.creamSodaPictureBox_Click);
            // 
            // totalGroupBox
            // 
            this.totalGroupBox.Controls.Add(this.totalTextBox);
            this.totalGroupBox.Controls.Add(this.totalLabel);
            this.totalGroupBox.Location = new System.Drawing.Point(302, 312);
            this.totalGroupBox.Name = "totalGroupBox";
            this.totalGroupBox.Size = new System.Drawing.Size(262, 139);
            this.totalGroupBox.TabIndex = 1;
            this.totalGroupBox.TabStop = false;
            this.totalGroupBox.Text = "groupBox6";
            // 
            // totalTextBox
            // 
            this.totalTextBox.Location = new System.Drawing.Point(64, 71);
            this.totalTextBox.Multiline = true;
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(117, 33);
            this.totalTextBox.TabIndex = 15;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(86, 29);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(60, 13);
            this.totalLabel.TabIndex = 9;
            this.totalLabel.Text = "Total Sales";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(203, 460);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(302, 460);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Load Drinks";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // selectLabel
            // 
            this.selectLabel.AutoSize = true;
            this.selectLabel.Location = new System.Drawing.Point(254, 18);
            this.selectLabel.Name = "selectLabel";
            this.selectLabel.Size = new System.Drawing.Size(74, 13);
            this.selectLabel.TabIndex = 4;
            this.selectLabel.Text = "Select a Drink";
            // 
            // drinkVendingMachine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 495);
            this.Controls.Add(this.selectLabel);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.grapeSodeGroupBox);
            this.Controls.Add(this.totalGroupBox);
            this.Controls.Add(this.rootBeerGroupBox);
            this.Controls.Add(this.leonLimeGroupBox);
            this.Controls.Add(this.creamSodaGroupBox);
            this.Controls.Add(this.colaGroupBox);
            this.Name = "drinkVendingMachine";
            this.Text = "Drinks Vending Machine";
            this.Load += new System.EventHandler(this.drinkVendingMachine_Load);
            this.colaGroupBox.ResumeLayout(false);
            this.colaGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colaPictureBox)).EndInit();
            this.rootBeerGroupBox.ResumeLayout(false);
            this.rootBeerGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rootBeerPictureBox)).EndInit();
            this.leonLimeGroupBox.ResumeLayout(false);
            this.leonLimeGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lemonLimePictureBox)).EndInit();
            this.grapeSodeGroupBox.ResumeLayout(false);
            this.grapeSodeGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grapesodaPictureBox)).EndInit();
            this.creamSodaGroupBox.ResumeLayout(false);
            this.creamSodaGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.creamSodaPictureBox)).EndInit();
            this.totalGroupBox.ResumeLayout(false);
            this.totalGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox colaGroupBox;
        private System.Windows.Forms.TextBox colaTextBox;
        private System.Windows.Forms.Label colaPriceLabel;
        private System.Windows.Forms.Label colaLeftLabel;
        private System.Windows.Forms.PictureBox colaPictureBox;
        private System.Windows.Forms.GroupBox rootBeerGroupBox;
        private System.Windows.Forms.Label rootBeerLeftLabel;
        private System.Windows.Forms.Label rootBeerPriceLabel;
        private System.Windows.Forms.PictureBox rootBeerPictureBox;
        private System.Windows.Forms.GroupBox leonLimeGroupBox;
        private System.Windows.Forms.Label lemonLimeLeftLabel;
        private System.Windows.Forms.Label lemonLimePriceLabel;
        private System.Windows.Forms.PictureBox lemonLimePictureBox;
        private System.Windows.Forms.GroupBox grapeSodeGroupBox;
        private System.Windows.Forms.Label grapeSodaleftLabel;
        private System.Windows.Forms.Label grapeSodaPriceLabel;
        private System.Windows.Forms.PictureBox grapesodaPictureBox;
        private System.Windows.Forms.GroupBox creamSodaGroupBox;
        private System.Windows.Forms.Label creamSodaLeftLabel;
        private System.Windows.Forms.Label creamSodaPriceLabel;
        private System.Windows.Forms.PictureBox creamSodaPictureBox;
        private System.Windows.Forms.GroupBox totalGroupBox;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox rootBeerTextBox;
        private System.Windows.Forms.TextBox lemonLimeTextBox;
        private System.Windows.Forms.TextBox grapeSodaTextBox;
        private System.Windows.Forms.TextBox creamSodaTextBox;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.Label selectLabel;
    }
}

