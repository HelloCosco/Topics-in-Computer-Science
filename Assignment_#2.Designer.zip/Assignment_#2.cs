﻿//Header files
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Namespace
namespace WindowsFormsApp11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Calculate Revenue button
        private void butCalRev_Click(object sender, EventArgs e)
        {
            double CATickets;
            double CBTickets;
            double CCTickets;
            double TotalRev;

            //When you click on the button
            //get values for text box1
            //calculate sum of the 3 tickets
            //Display all values into box2
            if (txtCASold.Text != "" && txtCBSold.Text != "" && txtCCSold.Text != "")
            {
                //Read sold Tickets
                CATickets = double.Parse(txtCASold.Text);
                CBTickets = double.Parse(txtCBSold.Text);
                CCTickets = double.Parse(txtCCSold.Text);

                //Calculate Revenue
                CATickets = CATickets * 15.0;
                CBTickets = CBTickets * 12.0;
                CCTickets = CCTickets * 9.0;

                //Calculate Total Revenue
                TotalRev = CATickets + CBTickets + CCTickets;

                //Result to boxes
                txtCARev.Text = CATickets.ToString("c");
                txtCBRev.Text = CBTickets.ToString("c");
                txtCCRev.Text = CCTickets.ToString("c");
                txtTotalRev.Text = TotalRev.ToString("c");
            }
        }
        //Clear button
        private void butClear_Click(object sender, EventArgs e)
        {
            //Reset controls
            txtCASold.Text = "";
            txtCBSold.Text = "";
            txtCCSold.Text = "";
            txtCARev.Text = "";
            txtCBRev.Text = "";
            txtCCRev.Text = "";
            txtTotalRev.Text = "";

        }
        //Exit button
        private void butExit_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }
    }
}
//End of Script