﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SetPreferedCustomerData
            (PreferredCustomer objPrefCustomer)
        {
            //variable declaration 
            int customerNumber;
            decimal purchaseAmount;
            decimal fivePercent = 0.05m;
            decimal sixPercent = 0.06m;
            decimal sevenPercent = 0.07m;
            decimal tenPercent = 0.1m;

            //checks customer number if typed numerically or not
            if (int.TryParse(txt_cusNumber.Text, out customerNumber))
            {
                objPrefCustomer.customerNumber = customerNumber;

            }
            else
            {
                MessageBox.Show("Invalid customer" + "number");
            }

            //check purchase amount is type numeric or not
            if (decimal.TryParse(txt_PurchaseAmount.Text, out purchaseAmount))
            {
                objPrefCustomer.purchaseAmount = purchaseAmount;
            }
            else
            {
                MessageBox.Show("Invalid" + "customer number");
            }

            //check the purchase amount value amoung the range of 500.1000,1500,2000
            if (objPrefCustomer.purchaseAmount >= 500 && objPrefCustomer.purchaseAmount < 1000)
            {
                objPrefCustomer.customerDiscount = (objPrefCustomer.purchaseAmount * fivePercent);
            }
            else if (objPrefCustomer.purchaseAmount >= 1000 && objPrefCustomer.purchaseAmount < 1500)
            {
                objPrefCustomer.customerDiscount = (objPrefCustomer.purchaseAmount * sixPercent);
            }
            else if (objPrefCustomer.purchaseAmount >= 1500 && objPrefCustomer.purchaseAmount < 2000)
            {
                objPrefCustomer.customerDiscount = (objPrefCustomer.purchaseAmount * sevenPercent);
            }
            else if (objPrefCustomer.purchaseAmount >= 2000)
            {
                objPrefCustomer.customerDiscount = (objPrefCustomer.purchaseAmount * tenPercent);
            }
        }

        private void setLabelAppearance()
        {
            //change the fore color of a label control
            lbl_cusNumber.ForeColor = Color.Tomato;
            label4.ForeColor = Color.Tomato;
            label5.ForeColor = Color.Tomato;
            lbl_TotalAmount.ForeColor = Color.Tomato;

            //change the Border style of a label control
            lbl_cusNumber.BorderStyle = BorderStyle.FixedSingle;
            label4.BorderStyle = BorderStyle.FixedSingle;
            label5.BorderStyle = BorderStyle.FixedSingle;
            lbl_TotalAmount.BorderStyle = BorderStyle.FixedSingle;
        }

        private void btn_getDiscount_Click(object sender, EventArgs e)
        {
            //object creation for preferredCustomer class
            PreferredCustomer objPrefCustomer = new PreferredCustomer();

            //set properties to PreferredCustomer object
            SetPreferedCustomerData(objPrefCustomer);

            //accessing and displaying PreferredCustomer properties
            lbl_cusNumber.Text = objPrefCustomer.customerNumber.ToString();
            label4.Text = objPrefCustomer.purchaseAmount.ToString("c");
            label5.Text = objPrefCustomer.customerDiscount.ToString("c");
            lbl_TotalAmount.Text = (objPrefCustomer.purchaseAmount - objPrefCustomer.customerDiscount).ToString("c");

            //setting label control appearance
            setLabelAppearance();
        }
    }
}
        