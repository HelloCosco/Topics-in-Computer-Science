﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management;
using System.IO;
//
//
// In addition to adding Using System.Management above you will need to add a reference to a code library
// You'll need to add the reference (.DLL) in your project manually. To do that follow these steps:
//
// Right Click on Project, Add References
//
// Select the Assemblies(framework) Tab and Search for System.Management and finally add the reference and click OK.
//
//
namespace Hardware_InformationApp_Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "Hardware Specs For This Computer";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myVideoObject = new ManagementObjectSearcher("select * from Win32_VideoController");

            foreach (ManagementObject obj in myVideoObject.Get())
            {
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("AdapterRAM  -  " + obj["AdapterRAM"]);
                listBox1.Items.Add("AdapterDACType  -  " + obj["AdapterDACType"]);
                listBox1.Items.Add("Monochrome  -  " + obj["Monochrome"]);
                listBox1.Items.Add("InstalledDisplayDrivers  -  " + obj["InstalledDisplayDrivers"]);
                listBox1.Items.Add("DriverVersion  -  " + obj["DriverVersion"]);
                listBox1.Items.Add("VideoProcessor  -  " + obj["VideoProcessor"]);
                listBox1.Items.Add("VideoArchitecture  -  " + obj["VideoArchitecture"]);
                listBox1.Items.Add("VideoMemoryType  -  " + obj["VideoMemoryType"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "Video Specs For This Computer";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myCacheObject = new ManagementObjectSearcher("select * from Win32_CacheMemory");

            foreach (ManagementObject obj in myCacheObject.Get())
            {
                listBox1.Items.Add("Level  -  " + obj["Level"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("CacheType  -  " + obj["CacheType"]);
                listBox1.Items.Add("CacheSpeed  -  " + obj["CacheSpeed"]);
                listBox1.Items.Add("BlockSize  -  " + obj["BlockSize"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("InstalledSize  -  " + obj["InstalledSize"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "Cache Memory Specs For This Computer";
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myProcessorObject = new ManagementObjectSearcher("select * from Win32_Processor");

            foreach (ManagementObject obj in myProcessorObject.Get())
            {
                listBox1.Items.Add("Level  -  " + obj["Level"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("CurrentClockSpeed  -  " + obj["CurrentClockSpeed"]);
                listBox1.Items.Add("Version  -  " + obj["Version"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("CpuStatus  -  " + obj["CpuStatus"]);
                listBox1.Items.Add("Level  -  " + obj["Level"]);
                listBox1.Items.Add("AddressWidth  -  " + obj["AddressWidth"]);
                listBox1.Items.Add("Architecture  -  " + obj["Architecture"]);
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("ConfigManagerErrorCode  -  " + obj["ConfigManagerErrorCode"]);
                listBox1.Items.Add("ConfigManagerUserConfig  -  " + obj["ConfigManagerUserConfig"]);
                listBox1.Items.Add("CpuStatus  -  " + obj["CpuStatus"]);
                listBox1.Items.Add("CurrentVoltage  -  " + obj["CurrentVoltage"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("DataWidth  -  " + obj["DataWidth"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("ExtClock  -  " + obj["ExtClock"]);
                listBox1.Items.Add("Family  -  " + obj["Family"]);
                listBox1.Items.Add("InstallDate  -  " + obj["InstallDate"]);
                listBox1.Items.Add("L2CacheSize  -  " + obj["L2CacheSize"]);
                listBox1.Items.Add("L2CacheSpeed  -  " + obj["L2CacheSpeed"]);
                listBox1.Items.Add("L3CacheSize  -  " + obj["L3CacheSize"]);
                listBox1.Items.Add("L3CacheSpeed  -  " + obj["L3CacheSpeed"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("LoadPercentage  -  " + obj["LoadPercentage"]);
                listBox1.Items.Add("MaxClockSpeed  -  " + obj["MaxClockSpeed"]);
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("ExtClock  -  " + obj["ExtClock"]);
                listBox1.Items.Add("Family  -  " + obj["Family"]);
                listBox1.Items.Add("NumberOfCores  -  " + obj["NumberOfCores"]);
                listBox1.Items.Add("NumberOfLogicalProcessors  -  " + obj["NumberOfLogicalProcessors"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("PowerManagementCapabilities  -  " + obj["PowerManagementCapabilities"]);
                listBox1.Items.Add("PowerManagementSupported  -  " + obj["PowerManagementSupported"]);
                listBox1.Items.Add("UpgradeMethod  -  " + obj["UpgradeMethod"]);
                listBox1.Items.Add("VirtualizationFirmwareEnabled  -  " + obj["VirtualizationFirmwareEnabled"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "Processor Specs For This Computer";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void saveBut_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Title = "Save text Files";
            dlg.DefaultExt = "txt";
            dlg.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
                {
                StreamWriter writer = new StreamWriter(dlg.FileName);

                for (int i=0; i < listBox1.Items.Count; i++)
                {
                    writer.WriteLine((string)listBox1.Items[i]);
                   
                }
                writer.Close();
            }

            dlg.Dispose();


        }

        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myOperatingSystemObject = new ManagementObjectSearcher("select * from Win32_OperatingSystem ");

            foreach (ManagementObject obj in myOperatingSystemObject.Get())
            {
                listBox1.Items.Add("BootDevice  -  " + obj["BootDevice"]);
                listBox1.Items.Add("BuildNumber  -  " + obj["BuildNumber"]);
                listBox1.Items.Add("BuildType  -  " + obj["BuildType"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("CodeSet  -  " + obj["CodeSet"]);
                listBox1.Items.Add("CountryCode  -  " + obj["CountryCode"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("CSCreationClassName  -  " + obj["CSCreationClassName"]);
                listBox1.Items.Add("CSDVersion  -  " + obj["CSDVersion"]);
                listBox1.Items.Add("CSName  -  " + obj["CSName"]);
                listBox1.Items.Add("CurrentTimeZone  -  " + obj["CurrentTimeZone"]);
                listBox1.Items.Add("DataExecutionPrevention_Available  -  " + obj["DataExecutionPrevention_Available"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("DataExecutionPrevention_32BitApplications  -  " + obj["DataExecutionPrevention_32BitApplications"]);
                listBox1.Items.Add("DataExecutionPrevention_Drivers  -  " + obj["DataExecutionPrevention_Drivers"]);
                listBox1.Items.Add("DataExecutionPrevention_SupportPolicy  -  " + obj["DataExecutionPrevention_SupportPolicy"]);
                listBox1.Items.Add("Debug  -  " + obj["Debug"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("Distributed  -  " + obj["Distributed"]);
                listBox1.Items.Add("EncryptionLevel  -  " + obj["EncryptionLevel"]);
                listBox1.Items.Add("FreePhysicalMemory  -  " + obj["FreePhysicalMemory"]);
                listBox1.Items.Add("CSName  -  " + obj["CSName"]);
                listBox1.Items.Add("CurrentTimeZone  -  " + obj["CurrentTimeZone"]);
                listBox1.Items.Add("DataExecutionPrevention_Available  -  " + obj["DataExecutionPrevention_Available"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("LargeSystemCache  -  " + obj["LargeSystemCache"]);
                listBox1.Items.Add("Locale  -  " + obj["Locale"]);
                listBox1.Items.Add("Manufacturer  -  " + obj["Manufacturer"]);
                listBox1.Items.Add("MUILanguages  -  " + obj["MUILanguages"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("NumberOfLicensedUsers  -  " + obj["NumberOfLicensedUsers"]);
                listBox1.Items.Add("NumberOfUsers  -  " + obj["NumberOfUsers"]);
                listBox1.Items.Add("Organization  -  " + obj["Organization"]);
                listBox1.Items.Add("PlusProductID  -  " + obj["PlusProductID"]);
                listBox1.Items.Add("RegisteredUser  -  " + obj["RegisteredUser"]);
                listBox1.Items.Add("SerialNumber  -  " + obj["SerialNumber"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("ServicePackMajorVersion  -  " + obj["ServicePackMajorVersion"]);
                listBox1.Items.Add("ServicePackMinorVersion  -  " + obj["ServicePackMinorVersion"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("SuiteMask  -  " + obj["SuiteMask"]);
                listBox1.Items.Add("SystemDevice  -  " + obj["SystemDevice"]);
                listBox1.Items.Add("SystemDirectory  -  " + obj["SystemDirectory"]);
                listBox1.Items.Add("SystemDrive  -  " + obj["SystemDrive"]);
                listBox1.Items.Add("TotalVirtualMemorySize  -  " + obj["TotalVirtualMemorySize"]);
                listBox1.Items.Add("Version  -  " + obj["Version"]);
                listBox1.Items.Add("WindowsDirectory  -  " + obj["WindowsDirectory"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "OperatingSystem Specs For This Computer";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myPrinterObject = new ManagementObjectSearcher("select * from Win32_Printer ");

            foreach (ManagementObject obj in myPrinterObject.Get())
            {
                listBox1.Items.Add("Attributes  -  " + obj["Attributes"]);
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("AveragePagesPerMinute  -  " + obj["AveragePagesPerMinute"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("Comment  -  " + obj["Comment"]);
                listBox1.Items.Add("ConfigManagerErrorCode  -  " + obj["ConfigManagerErrorCode"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("CurrentCharSet  -  " + obj["CurrentCharSet"]);
                listBox1.Items.Add("Default  -  " + obj["Default"]);
                listBox1.Items.Add("DefaultCopies  -  " + obj["DefaultCopies"]);
                listBox1.Items.Add("DefaultNumberUp -  " + obj["DefaultNumberUp"]);
                listBox1.Items.Add("DefaultPaperType  -  " + obj["DefaultPaperType"]);
                listBox1.Items.Add("DefaultPriority  -  " + obj["DefaultPriority"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DetectedErrorState  -  " + obj["DetectedErrorState"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("Direct  -  " + obj["Direct"]);
                listBox1.Items.Add("DoCompleteFirst  -  " + obj["DoCompleteFirst"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("DriverName  -  " + obj["DriverName"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("Hidden  -  " + obj["Hidden"]);
                listBox1.Items.Add("KeepPrintedJobs -  " + obj["KeepPrintedJobs"]);
                listBox1.Items.Add("Location  -  " + obj["Location"]);
                listBox1.Items.Add("MarkingTechnology  -  " + obj["MarkingTechnology"]);
                listBox1.Items.Add("MaxCopies  -  " + obj["MaxCopies"]);
                listBox1.Items.Add("MaxNumberUp  -  " + obj["MaxNumberUp"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("Network  -  " + obj["Network"]);
                listBox1.Items.Add("Parameters  -  " + obj["Parameters"]);
                listBox1.Items.Add("PNPDeviceID -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("PortName  -  " + obj["PortName"]);
                listBox1.Items.Add("PowerManagementSupported  -  " + obj["PowerManagementSupported"]);
                listBox1.Items.Add("PrinterState  -  " + obj["PrinterState"]);
                listBox1.Items.Add("PrinterStatus  -  " + obj["PrinterStatus"]);
                listBox1.Items.Add("PrintJobDataType  -  " + obj["PrintJobDataType"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("PrintProcessor  -  " + obj["PrintProcessor"]);
                listBox1.Items.Add("Priority  -  " + obj["Priority"]);
                listBox1.Items.Add("Published  -  " + obj["Published"]);
                listBox1.Items.Add("Queued  -  " + obj["Queued"]);
                listBox1.Items.Add("RawOnly -  " + obj["RawOnly"]);
                listBox1.Items.Add("SeparatorFile  -  " + obj["SeparatorFile"]);
                listBox1.Items.Add("ServerName  -  " + obj["ServerName"]);
                listBox1.Items.Add("Shared  -  " + obj["Shared"]);
                listBox1.Items.Add("ShareName -  " + obj["ShareName"]);
                listBox1.Items.Add("SpoolEnabled  -  " + obj["SpoolEnabled"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("StatusInfo  -  " + obj["StatusInfo"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("WorkOffline  -  " + obj["WorkOffline"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "Printer Specs For This Computer";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myNetworkAdapterObject = new ManagementObjectSearcher("select * from Win32_NetworkAdapter  ");

            foreach (ManagementObject obj in myNetworkAdapterObject.Get())
            {
                listBox1.Items.Add("AdapterType  -  " + obj["AdapterType"]);
                listBox1.Items.Add("AdapterTypeID  -  " + obj["AdapterTypeID"]);
                listBox1.Items.Add("AutoSense  -  " + obj["AutoSense"]);
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("ConfigManagerErrorCode  -  " + obj["ConfigManagerErrorCode"]);
                listBox1.Items.Add("ConfigManagerUserConfig  -  " + obj["ConfigManagerUserConfig"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("GUID  -  " + obj["GUID"]);
                listBox1.Items.Add("Index  -  " + obj["Index"]);
                listBox1.Items.Add("InterfaceIndex  -  " + obj["InterfaceIndex"]);
                listBox1.Items.Add("LastErrorCode  -  " + obj["LastErrorCode"]);
                listBox1.Items.Add("MACAddress  -  " + obj["MACAddress"]);
                listBox1.Items.Add("Manufacturer  -  " + obj["Manufacturer"]);
                listBox1.Items.Add("MaxNumberControlled  -  " + obj["MaxNumberControlled"]);
                listBox1.Items.Add("MaxSpeed  -  " + obj["MaxSpeed"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("NetConnectionID  -  " + obj["NetConnectionID"]);
                listBox1.Items.Add("NetConnectionStatus  -  " + obj["NetConnectionStatus"]);
                listBox1.Items.Add("NetEnabled  -  " + obj["NetEnabled"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("PermanentAddress  -  " + obj["PermanentAddress"]);
                listBox1.Items.Add("PhysicalAdapter  -  " + obj["PhysicalAdapter"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("ProductName  -  " + obj["ProductName"]);
                listBox1.Items.Add("ServiceName  -  " + obj["ServiceName"]);
                listBox1.Items.Add("Speed  -  " + obj["Speed"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("StatusInfo  -  " + obj["StatusInfo"]);
                listBox1.Items.Add("SystemCreationClassName  -  " + obj["SystemCreationClassName"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("TimeOfLastReset  -  " + obj["TimeOfLastReset"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "Network Adpater Specs For This Computer";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myDiskDriveObject = new ManagementObjectSearcher("select * from Win32_DiskDrive    ");

            foreach (ManagementObject obj in myDiskDriveObject.Get())
            {
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("BytesPerSector  -  " + obj["BytesPerSector"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("CompressionMethod  -  " + obj["CompressionMethod"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("DefaultBlockSize  -  " + obj["DefaultBlockSize"]);
                listBox1.Items.Add("ErrorMethodology  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("FirmwareRevision  -  " + obj["FirmwareRevision"]);
                listBox1.Items.Add("Index  -  " + obj["Index"]);
                listBox1.Items.Add("InterfaceType  -  " + obj["InterfaceType"]);
                listBox1.Items.Add("LastErrorCode  -  " + obj["LastErrorCode"]);
                listBox1.Items.Add("Manufacturer  -  " + obj["Manufacturer"]);
                listBox1.Items.Add("MaxBlockSize  -  " + obj["MaxBlockSize"]);
                listBox1.Items.Add("MaxMediaSize  -  " + obj["MaxMediaSize"]);
                listBox1.Items.Add("MediaType  -  " + obj["MediaType"]);
                listBox1.Items.Add("MinBlockSize  -  " + obj["MinBlockSize"]);
                listBox1.Items.Add("Model  -  " + obj["Model"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("NeedsCleaning  -  " + obj["NeedsCleaning"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("NumberOfMediaSupported  -  " + obj["NumberOfMediaSupported"]);
                listBox1.Items.Add("Partitions  -  " + obj["Partitions"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("PowerManagementSupported  -  " + obj["PowerManagementSupported"]);
                listBox1.Items.Add("SCSIBus  -  " + obj["SCSIBus"]);
                listBox1.Items.Add("SCSILogicalUnit  -  " + obj["SCSILogicalUnit"]);
                listBox1.Items.Add("SCSIPort  -  " + obj["SCSIPort"]);
                listBox1.Items.Add("SCSITargetId  -  " + obj["SCSITargetId"]);
                listBox1.Items.Add("SectorsPerTrack  -  " + obj["SectorsPerTrack"]);
                listBox1.Items.Add("SerialNumber  -  " + obj["SerialNumber"]);
                listBox1.Items.Add("Signature  -  " + obj["Signature"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("Size  -  " + obj["Size"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("StatusInfo  -  " + obj["StatusInfo"]);
                listBox1.Items.Add("SystemCreationClassName  -  " + obj["SystemCreationClassName"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("TotalCylinders  -  " + obj["TotalCylinders"]);
                listBox1.Items.Add("TotalHeads  -  " + obj["TotalHeads"]);
                listBox1.Items.Add("TotalSectors  -  " + obj["TotalSectors"]);
                listBox1.Items.Add("TotalTracks  -  " + obj["TotalTracks"]);
                listBox1.Items.Add("TracksPerCylinder  -  " + obj["TracksPerCylinder"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "DiskDrive Specs For This Computer";
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myDiskPartitionObject = new ManagementObjectSearcher("select * from Win32_DiskPartition   ");

            foreach (ManagementObject obj in myDiskPartitionObject.Get())
            {
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("StatusInfo  -  " + obj["StatusInfo"]);
                listBox1.Items.Add("Access  -  " + obj["Access"]);
                listBox1.Items.Add("BlockSize  -  " + obj["BlockSize"]);
                listBox1.Items.Add("Bootable  -  " + obj["Bootable"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("ConfigManagerErrorCode  -  " + obj["ConfigManagerErrorCode"]);
                listBox1.Items.Add("ConfigManagerUserConfig  -  " + obj["ConfigManagerUserConfig"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("DiskIndex  -  " + obj["DiskIndex"]);
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("ErrorMethodology  -  " + obj["ErrorMethodology"]);
                listBox1.Items.Add("HiddenSectors  -  " + obj["HiddenSectors"]);
                listBox1.Items.Add("Index  -  " + obj["Index"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("LastErrorCode  -  " + obj["LastErrorCode"]);
                listBox1.Items.Add("InstallDate  -  " + obj["InstallDate"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("NumberOfBlocks  -  " + obj["NumberOfBlocks"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("PowerManagementSupported  -  " + obj["PowerManagementSupported"]);
                listBox1.Items.Add("PrimaryPartition  -  " + obj["PrimaryPartition"]);
                listBox1.Items.Add("Purpose  -  " + obj["Purpose"]);
                listBox1.Items.Add("RewritePartition  -  " + obj["RewritePartition"]);
                listBox1.Items.Add("Size  -  " + obj["Size"]);
                listBox1.Items.Add("StartingOffset  -  " + obj["StartingOffset"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("SystemCreationClassName  -  " + obj["SystemCreationClassName"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("Type  -  " + obj["Type"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "DiskPartition Specs For This Computer";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myIDEControllerObject = new ManagementObjectSearcher("select * from Win32_IDEController ");

            foreach (ManagementObject obj in myIDEControllerObject.Get())
            {
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("ConfigManagerErrorCode  -  " + obj["ConfigManagerErrorCode"]);
                listBox1.Items.Add("ConfigManagerUserConfig  -  " + obj["ConfigManagerUserConfig"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("LastErrorCode  -  " + obj["LastErrorCode"]);
                listBox1.Items.Add("Manufacturer  -  " + obj["Manufacturer"]);
                listBox1.Items.Add("MaxNumberControlled  -  " + obj["MaxNumberControlled"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("PowerManagementSupported  -  " + obj["PowerManagementSupported"]);
                listBox1.Items.Add("ProtocolSupported  -  " + obj["ProtocolSupported"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("StatusInfo  -  " + obj["StatusInfo"]);
                listBox1.Items.Add("SystemCreationClassName  -  " + obj["SystemCreationClassName"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("TimeOfLastReset  -  " + obj["TimeOfLastReset"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "IDEController Specs For This Computer";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myIRQResourceObject = new ManagementObjectSearcher("select * from Win32_IRQResource  ");

            foreach (ManagementObject obj in myIRQResourceObject.Get())
            {
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("CSCreationClassName  -  " + obj["CSCreationClassName"]);
                listBox1.Items.Add("CSName  -  " + obj["CSName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("Hardware  -  " + obj["Hardware"]);
                listBox1.Items.Add("InstallDate  -  " + obj["InstallDate"]);
                listBox1.Items.Add("IRQNumber  -  " + obj["IRQNumber"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("Shareable  -  " + obj["Shareable"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("TriggerLevel  -  " + obj["TriggerLevel"]);
                listBox1.Items.Add("TriggerType  -  " + obj["TriggerType"]);
                listBox1.Items.Add("Vector  -  " + obj["Vector"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "IRQResources Specs For This Computer";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher mySoundDeviceObject = new ManagementObjectSearcher("select * from Win32_SoundDevice  ");

            foreach (ManagementObject obj in mySoundDeviceObject.Get())
            {
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("ConfigManagerErrorCode  -  " + obj["ConfigManagerErrorCode"]);
                listBox1.Items.Add("ConfigManagerUserConfig  -  " + obj["ConfigManagerUserConfig"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("DMABufferSize  -  " + obj["DMABufferSize"]);
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("InstallDate  -  " + obj["InstallDate"]);
                listBox1.Items.Add("LastErrorCode  -  " + obj["LastErrorCode"]);
                listBox1.Items.Add("Manufacturer  -  " + obj["Manufacturer"]);
                listBox1.Items.Add("MPU401Address  -  " + obj["MPU401Address"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("PowerManagementSupported  -  " + obj["PowerManagementSupported"]);
                listBox1.Items.Add("ProductName  -  " + obj["ProductName"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("StatusInfo  -  " + obj["StatusInfo"]);
                listBox1.Items.Add("SystemCreationClassName  -  " + obj["SystemCreationClassName"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "SoundDevice Specs For This Computer";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myBusObject = new ManagementObjectSearcher("select * from Win32_Bus   ");

            foreach (ManagementObject obj in myBusObject.Get())
            {
                listBox1.Items.Add("Availability  -  " + obj["Availability"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("ConfigManagerErrorCode  -  " + obj["ConfigManagerErrorCode"]);
                listBox1.Items.Add("ConfigManagerUserConfig  -  " + obj["ConfigManagerUserConfig"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("BusNum  -  " + obj["BusNum"]);
                listBox1.Items.Add("BusType  -  " + obj["BusType"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                listBox1.Items.Add("ErrorCleared  -  " + obj["ErrorCleared"]);
                listBox1.Items.Add("LastErrorCode  -  " + obj["LastErrorCode"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("StatusInfo  -  " + obj["StatusInfo"]);
                listBox1.Items.Add("SystemCreationClassName  -  " + obj["SystemCreationClassName"]);
                listBox1.Items.Add("SystemName  -  " + obj["SystemName"]);
                listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                textBox1.Text = "DeviceBus Specs For This Computer";
            }
        }

        //Extra Credit
        //File utility to copy, move and delete files
        private void button16_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            // Show the FolderBrowserDialog.
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                listBox1.Text = folderDlg.SelectedPath;
                Environment.SpecialFolder root = folderDlg.RootFolder;
            }
        }

        //Does not work
        //Need to fins proper class syntax
        private void button13_Click(object sender, EventArgs e) 
        {
            // GetDrives() method retrieves the drive names of all logical drives on a computer. 
            DriveInfo[] drives = DriveInfo.GetDrives();
            foreach (DriveInfo drive in drives)
            {
                if (drive.IsReady)
                {
                    listBox1.Items.Add("Drive Name : " + drive.Name);
                    listBox1.Items.Add("Drive Volume name : " + drive.VolumeLabel);
                    listBox1.Items.Add("Drive Format : " + drive.DriveFormat);
                    listBox1.Items.Add("Drive Type : " + drive.DriveType);
                    listBox1.Items.Add("Drive root directory name : " + drive.RootDirectory);
                    listBox1.Items.Add("Drive free space: " + drive.AvailableFreeSpace);
                    listBox1.Items.Add("Total Free space on the drive : " + drive.TotalFreeSpace);
                    listBox1.Items.Add("Total disk size : " + drive.TotalSize);
                    listBox1.Items.Add("----------------------------------------------------------------------------------------------------------------");
                    textBox1.Text = "DriveInfo Specs For This Computer";
                }
            }
            
        }
            
        
        
    }
}

