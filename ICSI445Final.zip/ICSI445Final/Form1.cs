﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management;
//
//
// In addition to adding Using System.Management above you will need to add a reference to a code library
// You'll need to add the reference (.DLL) in your project manually. To do that follow these steps:
//
// Right Click on Project, Add References
//
// Select the Assemblies(framework) Tab and Search for System.Management and finally add the reference and click OK.
//
//
namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "Hardware Specs For This Computer";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myVideoObject = new ManagementObjectSearcher("select * from Win32_VideoController");

            foreach (ManagementObject obj in myVideoObject.Get())
            {
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("AdapterRAM  -  " + obj["AdapterRAM"]);
                listBox1.Items.Add("AdapterDACType  -  " + obj["AdapterDACType"]);
                listBox1.Items.Add("Monochrome  -  " + obj["Monochrome"]);
                listBox1.Items.Add("InstalledDisplayDrivers  -  " + obj["InstalledDisplayDrivers"]);
                listBox1.Items.Add("DriverVersion  -  " + obj["DriverVersion"]);
                listBox1.Items.Add("VideoProcessor  -  " + obj["VideoProcessor"]);
                listBox1.Items.Add("VideoArchitecture  -  " + obj["VideoArchitecture"]);
                listBox1.Items.Add("VideoMemoryType  -  " + obj["VideoMemoryType"]);
                listBox1.Items.Add("----------------------------------------------------------------------");
                textBox1.Text = "Video Specs For This Computer";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myCacheObject = new ManagementObjectSearcher("select * from Win32_CacheMemory");

            foreach (ManagementObject obj in myCacheObject.Get())
            {
                listBox1.Items.Add("Level  -  " + obj["Level"]);
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("Caption  -  " + obj["Caption"]);
                listBox1.Items.Add("CacheType  -  " + obj["CacheType"]);
                listBox1.Items.Add("CacheSpeed  -  " + obj["CacheSpeed"]);  
                listBox1.Items.Add("BlockSize  -  " + obj["BlockSize"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("InstalledSize  -  " + obj["InstalledSize"]);
                listBox1.Items.Add("----------------------------------------------------------------------");
                textBox1.Text = "Cache Memory Specs For This Computer";
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            ManagementObjectSearcher myProcessorObject = new ManagementObjectSearcher("select * from Win32_Processor");

            foreach (ManagementObject obj in myProcessorObject.Get())
            {
                listBox1.Items.Add("Name  -  " + obj["Name"]);
                listBox1.Items.Add("Status  -  " + obj["Status"]);
                listBox1.Items.Add("AssetTag  -  " + obj["AssetTag"]);
                listBox1.Items.Add("CreationClassName  -  " + obj["CreationClassName"]);
                listBox1.Items.Add("Description  -  " + obj["Description"]);
                listBox1.Items.Add("DeviceID  -  " + obj["DeviceID"]);
                listBox1.Items.Add("ErrorDescription  -  " + obj["ErrorDescription"]);
                listBox1.Items.Add("OtherFamilyDescription  -  " + obj["OtherFamilyDescription"]);
                listBox1.Items.Add("PartNumber  -  " + obj["PartNumber"]);
                listBox1.Items.Add("PNPDeviceID  -  " + obj["PNPDeviceID"]);
                listBox1.Items.Add("Manufacturer  -  " + obj["Manufacturer"]);
                listBox1.Items.Add("ProcessorId  -  " + obj["ProcessorId"]);
                listBox1.Items.Add("----------------------------------------------------------------------");
                textBox1.Text = "Processor Specs For This Computer";
            }
        }
    }
}
