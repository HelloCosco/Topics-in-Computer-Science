﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp23
{
    struct drinks
    {
        public string drinkName;
        public double drinkCost;
        public int no_Of_Drinks_In_Machine;
    }
    public partial class drinkVendingMachine : Form
    {
        //this variable is used to keep total amount of sale
        double total = 0.00;

        // array variable to keep properties of all 5 type drinks
        drinks[] Drinks = new drinks[5];
        public drinkVendingMachine()
        {
            InitializeComponent();
        }

        private void drinkVendingMachine_Load(object sender, EventArgs e)
        {
            //set properties fo 1 drink 
            Drinks[0].drinkName = "Cola";
            Drinks[0].drinkCost = 1.00;
            Drinks[0].no_Of_Drinks_In_Machine = 20;

            //set properties for 2 drink
            Drinks[1].drinkName = "Root Beer";
            Drinks[1].drinkCost = 1.00;
            Drinks[1].no_Of_Drinks_In_Machine = 20;

            //set the properties for 3 drinks
            Drinks[2].drinkName = "Lemon Lime";
            Drinks[2].drinkCost = 1.00;
            Drinks[2].no_Of_Drinks_In_Machine = 20;

            //set the properties for 4 drink
            Drinks[3].drinkName = "Grape Soda";
            Drinks[3].drinkCost = 1.50;
            Drinks[3].no_Of_Drinks_In_Machine = 20;

            //set the properties for 5 drink
            Drinks[4].drinkName = "Cream Soda";
            Drinks[4].drinkCost = 1.50;
            Drinks[4].no_Of_Drinks_In_Machine = 20;

            //display the 1 drink cost
            colaPriceLabel.Text = Drinks[0].drinkCost.ToString("c");

            //display the 2 drink cost
            rootBeerPriceLabel.Text = Drinks[1].drinkCost.ToString("c");

            //display the 3 drink cost
            lemonLimePriceLabel.Text = Drinks[2].drinkCost.ToString("c");

            //display the 4 drink cost
            grapeSodaPriceLabel.Text = Drinks[3].drinkCost.ToString("c");

            //display the 5th drink cost
            creamSodaPriceLabel.Text = Drinks[4].drinkCost.ToString("c");

            //set stock quantity of each drink
            colaTextBox.Text = 20.ToString();
            rootBeerTextBox.Text = 20.ToString();
            lemonLimeTextBox.Text = 20.ToString();
            grapeSodaTextBox.Text = 20.ToString();
            creamSodaTextBox.Text = 20.ToString();

            //set the total value to 0 
            totalTextBox.Text = 0.00.ToString("c");
        }

        //if user selects cola drink
        private void colaPictureBox_Click(object sender, EventArgs e)
        {
            //check if cola drink is out of stock
            if (Drinks[0].no_Of_Drinks_In_Machine < 1)
            {
                //if drink are out of stock, display string 
                MessageBox.Show("Cola Drinks" + "are sold out...");
            }

            //if drinks are not out of stock
            else
            {
                //increase total value
                total += Drinks[0].drinkCost;

                //decrease the stock of cola by 1
                Drinks[0].no_Of_Drinks_In_Machine = Drinks[0].no_Of_Drinks_In_Machine - 1;

                //display the number of drinks left in stock
                colaTextBox.Text = Drinks[0].no_Of_Drinks_In_Machine.ToString();

                //display total amount 
                totalTextBox.Text = total.ToString("c");
            }
        }

        private void rootBeerPictureBox_Click(object sender, EventArgs e)
        {
            //check if rootBeer drink is out of stock
            if (Drinks[1].no_Of_Drinks_In_Machine < 1)
            {
                //display string
                MessageBox.Show("Root Beer" + "Drinks are sold out...");
            }

            //if drinks are not out of stock
            else
            {
                //increase the total value
                total += Drinks[1].drinkCost;

                //decrease the stock of rootBeer by 1
                Drinks[1].no_Of_Drinks_In_Machine = Drinks[1].no_Of_Drinks_In_Machine - 1;

                //display the number of drinks left in stock
                rootBeerTextBox.Text = Drinks[1].no_Of_Drinks_In_Machine.ToString();
                totalTextBox.Text = total.ToString("c");
            }
        }

        private void lemonLimePictureBox_Click(object sender, EventArgs e)
        {
            //check if lemonLime drink is out of stock 
            if (Drinks[2].no_Of_Drinks_In_Machine < 1)
            {
                //display string 
                MessageBox.Show("Lemon Lime" + "Drinks are sold out...");
            }

            //if drinks are not out of stock
            else
            {
                //increase the total value
                total += Drinks[2].drinkCost;

                //decrease the stock of Lemon lime by 1
                Drinks[2].no_Of_Drinks_In_Machine = Drinks[2].no_Of_Drinks_In_Machine - 1;

                //display the number of drinks left in stock
                lemonLimeTextBox.Text = Drinks[2].no_Of_Drinks_In_Machine.ToString();

                //display the total amount
                totalTextBox.Text = total.ToString("c");

            }
        }

        private void grapesodaPictureBox_Click(object sender, EventArgs e)
        {
            //check grape soda drink is out of stock
            if (Drinks[3].no_Of_Drinks_In_Machine < 1)
            {
                MessageBox.Show("Grape Soda" + "Drinks are sold out...");
            }

            //if drinks are not out of stock

            else
            {
                //increase the total value
                total += Drinks[3].drinkCost;

                //decrease the stock of grape soda by 1
                Drinks[3].no_Of_Drinks_In_Machine = Drinks[3].no_Of_Drinks_In_Machine - 1;

                //display the number of drinks left stock
                grapeSodaTextBox.Text = Drinks[3].no_Of_Drinks_In_Machine.ToString();

                //display the total amount
                totalTextBox.Text = total.ToString("c");
            }
        }

        private void creamSodaPictureBox_Click(object sender, EventArgs e)
        {
            //check if cream soda drink is out of stock or not
            if (Drinks[4].no_Of_Drinks_In_Machine < 1)
            {
                //display the string 
                MessageBox.Show("Cream Soda" + "Drinks are sold out...");
            }

            //if driks are not out of stock
            else
            {
                //increase the total value
                total += Drinks[4].drinkCost;

                //decrease the stock of cream soda by 1
                Drinks[4].no_Of_Drinks_In_Machine = Drinks[4].no_Of_Drinks_In_Machine - 1;

                //display the number of drinks left in stock
                creamSodaTextBox.Text = Drinks[4].no_Of_Drinks_In_Machine.ToString();

                //display the total amount
                totalTextBox.Text = total.ToString();

                //display the total amount
                totalTextBox.Text = total.ToString("c");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Text File|*.txt";
            saveFileDialog1.Title = "Save an Text File";
            saveFileDialog1.ShowDialog();

            // If the file name is not an empty string open it for saving.  
            if (saveFileDialog1.FileName != "drinks.txt")
            {
                // Saves the Image via a FileStream created by the OpenFile method.  
                System.IO.FileStream fs =
                   (System.IO.FileStream)saveFileDialog1.OpenFile();
                // Saves the Image in the appropriate ImageFormat based upon the  
                // File type selected in the dialog box.  
                // NOTE that the FilterIndex property is one-based.  

                fs.Close();
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"D:\",
                Title = "Browse Text Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "txt",
                Filter = "txt files (*.txt)|*.txt",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                button2.Text= openFileDialog1.FileName;
            }
        }
    }
}
    

