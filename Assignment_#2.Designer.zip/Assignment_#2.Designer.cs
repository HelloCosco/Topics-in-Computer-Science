﻿namespace WindowsFormsApp11
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCARev = new System.Windows.Forms.TextBox();
            this.txtCASold = new System.Windows.Forms.TextBox();
            this.txtCBSold = new System.Windows.Forms.TextBox();
            this.txtCCSold = new System.Windows.Forms.TextBox();
            this.txtCBRev = new System.Windows.Forms.TextBox();
            this.txtCCRev = new System.Windows.Forms.TextBox();
            this.txtTotalRev = new System.Windows.Forms.TextBox();
            this.butCalRev = new System.Windows.Forms.Button();
            this.butClear = new System.Windows.Forms.Button();
            this.butExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCCSold);
            this.groupBox1.Controls.Add(this.txtCBSold);
            this.groupBox1.Controls.Add(this.txtCASold);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(25, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 310);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tickets Sold";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTotalRev);
            this.groupBox2.Controls.Add(this.txtCCRev);
            this.groupBox2.Controls.Add(this.txtCBRev);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtCARev);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(413, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(360, 310);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Revenue Generated";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter the number of tickets sold for each class of seats.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Class A:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Class B:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Class C:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(76, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Class A:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(76, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Class B:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(76, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Class C:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(87, 233);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Total:";
            // 
            // txtCARev
            // 
            this.txtCARev.Location = new System.Drawing.Point(130, 53);
            this.txtCARev.Name = "txtCARev";
            this.txtCARev.ReadOnly = true;
            this.txtCARev.Size = new System.Drawing.Size(100, 20);
            this.txtCARev.TabIndex = 8;
            // 
            // txtCASold
            // 
            this.txtCASold.Location = new System.Drawing.Point(127, 115);
            this.txtCASold.Name = "txtCASold";
            this.txtCASold.Size = new System.Drawing.Size(100, 20);
            this.txtCASold.TabIndex = 9;
            // 
            // txtCBSold
            // 
            this.txtCBSold.Location = new System.Drawing.Point(127, 172);
            this.txtCBSold.Name = "txtCBSold";
            this.txtCBSold.Size = new System.Drawing.Size(100, 20);
            this.txtCBSold.TabIndex = 10;
            // 
            // txtCCSold
            // 
            this.txtCCSold.Location = new System.Drawing.Point(127, 226);
            this.txtCCSold.Name = "txtCCSold";
            this.txtCCSold.Size = new System.Drawing.Size(100, 20);
            this.txtCCSold.TabIndex = 11;
            // 
            // txtCBRev
            // 
            this.txtCBRev.Location = new System.Drawing.Point(130, 115);
            this.txtCBRev.Name = "txtCBRev";
            this.txtCBRev.ReadOnly = true;
            this.txtCBRev.Size = new System.Drawing.Size(100, 20);
            this.txtCBRev.TabIndex = 9;
            // 
            // txtCCRev
            // 
            this.txtCCRev.Location = new System.Drawing.Point(130, 172);
            this.txtCCRev.Name = "txtCCRev";
            this.txtCCRev.ReadOnly = true;
            this.txtCCRev.Size = new System.Drawing.Size(100, 20);
            this.txtCCRev.TabIndex = 10;
            // 
            // txtTotalRev
            // 
            this.txtTotalRev.Location = new System.Drawing.Point(130, 233);
            this.txtTotalRev.Name = "txtTotalRev";
            this.txtTotalRev.ReadOnly = true;
            this.txtTotalRev.Size = new System.Drawing.Size(100, 20);
            this.txtTotalRev.TabIndex = 11;
            // 
            // butCalRev
            // 
            this.butCalRev.Location = new System.Drawing.Point(211, 377);
            this.butCalRev.Name = "butCalRev";
            this.butCalRev.Size = new System.Drawing.Size(72, 40);
            this.butCalRev.TabIndex = 12;
            this.butCalRev.Text = "Calculate Revenue";
            this.butCalRev.UseVisualStyleBackColor = true;
            this.butCalRev.Click += new System.EventHandler(this.butCalRev_Click);
            // 
            // butClear
            // 
            this.butClear.Location = new System.Drawing.Point(309, 377);
            this.butClear.Name = "butClear";
            this.butClear.Size = new System.Drawing.Size(76, 40);
            this.butClear.TabIndex = 13;
            this.butClear.Text = "Clear";
            this.butClear.UseVisualStyleBackColor = true;
            this.butClear.Click += new System.EventHandler(this.butClear_Click);
            // 
            // butExit
            // 
            this.butExit.Location = new System.Drawing.Point(413, 377);
            this.butExit.Name = "butExit";
            this.butExit.Size = new System.Drawing.Size(75, 40);
            this.butExit.TabIndex = 14;
            this.butExit.Text = "Exit";
            this.butExit.UseVisualStyleBackColor = true;
            this.butExit.Click += new System.EventHandler(this.butExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.butExit);
            this.Controls.Add(this.butClear);
            this.Controls.Add(this.butCalRev);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Stadium Seating";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCCSold;
        private System.Windows.Forms.TextBox txtCBSold;
        private System.Windows.Forms.TextBox txtCASold;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtTotalRev;
        private System.Windows.Forms.TextBox txtCCRev;
        private System.Windows.Forms.TextBox txtCBRev;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCARev;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button butCalRev;
        private System.Windows.Forms.Button butClear;
        private System.Windows.Forms.Button butExit;
    }
}

