﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class PreferredCustomer : Customer
    {
        //variable declaration
        decimal _purchaseAmount;
        decimal _customerDiscount;

        //create purchase Amount property
        public decimal purchaseAmount
        {
            get
            {
                return _purchaseAmount;
            }
            set
            {
                _purchaseAmount = value;
            }
        }

        //create of customer Discount property
        public decimal customerDiscount
        {
            get
            {
                return _customerDiscount;
            }
            set
            {
                _customerDiscount = value;
            }
        }
    }
}

