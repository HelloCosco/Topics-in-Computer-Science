﻿using System;

using System.Collections.Generic;

using System.ComponentModel;

using System.Data;

using System.Drawing;

using System.Linq;

using System.Text;

using System.Windows.Forms;

namespace persons

{

    public partial class details : Form

    {

        public details()

        {

            InitializeComponent();

        }

        private void details_Load(object sender, EventArgs e)

        {

            //Adding data from previous form

            tbName.Text = Form1.pname;

            tbEmail.Text = Form1.pemail;

            tbPhoneNumber.Text = Form1.pphnum;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}