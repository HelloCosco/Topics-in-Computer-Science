﻿namespace EmployeeSearch2018
{


    partial class PersonnelDataSet
    {
    }
}

namespace EmployeeSearch2018.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
