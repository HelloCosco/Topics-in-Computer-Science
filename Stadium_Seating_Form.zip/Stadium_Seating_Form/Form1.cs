﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stadium_Seating_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_CalRev_Click(object sender, EventArgs e)
        {
            //declare variables
            double CATickets;
            double CBTickets;
            double CCTickets;
            double totalRev;

            //get values for the textbox of group1 and get result
            //calculate the summation of the three tickets and display all values
            //into groupbox2 textboxes

            if(txt_CASold.Text != "" && txt_CBSold.Text != "" && txt_CCSold.Text != "")
            {
                //read sold tickets values from textbox

                CATickets = double.Parse(txt_CASold.Text);
                CBTickets = double.Parse(txt_CBSold.Text);
                CCTickets = double.Parse(txt_CCSold.Text);

                //calculate revenue generated on each class

                CATickets = CATickets * 15.0;
                CBTickets = CBTickets * 12.0;
                CCTickets = CCTickets * 9.0;

                //calculate the total revenue of each class

                totalRev = CATickets + CBTickets + CCTickets;

                //assign total values to Textboxes

                txt_CARev.Text = CATickets.ToString("c");
                txt_CBRev.Text = CBTickets.ToString("c");
                txt_CCRev.Text = CCTickets.ToString("c");
                txt_totalRev.Text = totalRev.ToString("c");

            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_CARev.Text = "";
            txt_CBRev.Text = "";
            txt_CCRev.Text = "";
            txt_totalRev.Text = "";
            txt_CASold.Text = "";
            txt_CBSold.Text = "";
            txt_CCSold.Text = "";
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            //close application

            this.Close();
        }
    }
}
