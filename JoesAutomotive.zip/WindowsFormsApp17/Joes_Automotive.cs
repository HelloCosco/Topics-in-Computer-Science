﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            if(partsTextBox.Text=="" || laborTextBox.Text=="" || serviceTextBox.Text=="" || partTextBox.Text=="" || taxTextBox.Text=="" || totalTextBox.Text=="")
            {
                MessageBox.Show("Please Enter Input or Click on Load Changes, Thank You");
            }
            
               
                
            //declare abd initialize the variable to zero
            double oil = 0, lube = 0, radiator = 0, trans = 0, inspection = 0, muffler = 0, tire = 0;

            //conditions to check which checkBoxes are selected and if selected
            //constant values are stored into the respective variables
            if (oilCheckBox.Checked == true)
            {
                oil = 26;
            }

            if (lubeCheckBox.Checked == true)
            {
                lube = 18;
            }

            if (radiatorCheckBox.Checked == true)
            {
                radiator = 30;
            }

            if (tranCheckBox.Checked == true)
            {
                trans = 80;
            }

            if (inspectionCheckBox.Checked == true)
            {
                inspection = 15;
            }

            if (replaceCheckBox.Checked == true)
            {
                muffler = 100;
            }

            if (tireCheckBox.Checked == true)
            {
                tire = 20;
            }

            //gets all the values and convert to double
            double parts = double.Parse(partsTextBox.Text);
            double labor = double.Parse(laborTextBox.Text);

            //call OilLubeCharges function by passing the values of oil and lube as parameters 
            //return values is stored in the oillube
            double oillube = OilLubeCharges(oil, lube);

            //call FlushCharges function by passing the values of raiator and trans as parameter
            //return value is stores in the flush
            double flush = FlushCharges(radiator, trans);

            //call MiscCharges function by passing the value of inspection, muffler and tire as a parameter
            //return value is stored in the misc
            double misc = MiscCharges(inspection, muffler, tire);

            //call OtherCharges function by passing the values of parts and labor as parameter
            //return the value is stored 
            double other = OtherCharges(parts, labor);

            //call TaxCharges function by passing the values of parts, labor, oillube, flsuh,misc,and labor as parameter
            //return value stored in tax
            double tax = TaxCharges(parts, labor, oillube, flush, misc, labor);

            //call TotalCharges function by passing the values of oillube,flsuh,misc,other,and tax as parameters
            //return value stored in the total
            double total = TotalCharges(oillube, flush, misc, other, tax);

            //Get the total by summing up the oillube,flush,and misc value and stored values in service
            double services = oillube + flush + misc;

            //display services,other,tax and total values into the summary
            serviceTextBox.Text = services.ToString();
            partTextBox.Text = other.ToString();
            taxTextBox.Text = tax.ToString();
            totalTextBox.Text = total.ToString();


        }

        //define OilLubeCharges,FlushCharges,MIscCharges,OtherCharges,TaxCharges and TotalCharges
        private double OilLubeCharges(double oil, double lube)
        {
            //return charges of oil and lube
            return oil + lube;
        }

        private double FlushCharges(double radiator, double trans)
        {
            //returns total of radiator flush nad transmission flush
            return radiator + trans;
        }

        private double MiscCharges(double inspection, double muffler, double tire)
        {
            //total of inspection,muffler and tire rotation 
            return inspection + muffler + tire;
        }

        private double OtherCharges(double parts, double labor)
        {
            return parts + labor;
        }

        private double TaxCharges(double parts, double labor, double oillube, double flush, double misc, double other)
        {
            if (parts != 0 && labor != 0 && (oillube != 0 && flush != 0 && misc != 0 && other != 0))
            {
                //tax is 0.06 on parts
                return (0.06 * parts);
            }
            else
                return 0;
        }

        private double TotalCharges(double oillube, double flush, double misc, double other, double tax)
        {
            //total charges
            return oillube + flush + misc + other + tax;
        }


        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all checkboxes
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }


        //ClearOilLube will check which checkBox is checked in Oil and Lube group and set values to false
        private void ClearOilLube()
        {
            if (oilCheckBox.Checked == true)
            {
                oilCheckBox.Checked = false;
            }

            if (lubeCheckBox.Checked == true)
            {
                lubeCheckBox.Checked = false;
            }
        }

        //clearFlushes will check hich checkBox is checked in Flushes group and set values to false
        private void ClearFlushes()
        {
            if (radiatorCheckBox.Checked == true)
            {
                radiatorCheckBox.Checked = false;
            }

            if (tranCheckBox.Checked == true)
            {
                tranCheckBox.Checked = false;
            }
        }

        //clearMisc will check which checkBox is checked in Misc group and set values to false
        private void ClearMisc()
        {
            if (inspectionCheckBox.Checked == true)
            {
                inspectionCheckBox.Checked = false;
            }

            if (replaceCheckBox.Checked == true)
            {
                replaceCheckBox.Checked = false;
            }

            if (tireCheckBox.Checked == true)
            {
                tireCheckBox.Checked = false;
            }
        }

        //clearOther function will clear the data in the textBox of Parts and Labor and set values to false
        private void ClearOther()
        {
            partsTextBox.Text = null;
            laborTextBox.Text = null;
        }

        //clearFees function will clear the data in the textBox of summary and set values to false
        private void ClearFees()
        {
            serviceTextBox.Text = null;
            partTextBox.Text = null;
            taxTextBox.Text = null;
            totalTextBox.Text = null;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            if (f.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items.Clear();

                List<string> lines = new List<string>();
                using (StreamReader r = new StreamReader(f.OpenFile()))
                {
                    string line;
                    while ((line = r.ReadLine()) != null)
                    {
                        listBox1.Items.Add(line);

                    }

                }
            }
        }
    }
}
    

