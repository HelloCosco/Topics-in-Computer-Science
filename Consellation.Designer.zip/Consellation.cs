﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class OrionConstellation : Form
    {
        public OrionConstellation()
        {
            InitializeComponent();
        }

        private void butShow_Click(object sender, EventArgs e)
        {
            labBetelgeuse.Visible = true;
            labMeissa.Visible = true;
            labAlnitak.Visible = true;
            labAlnilam.Visible = true;
            labMintaka.Visible = true;
            labSaiph.Visible = true;
            labRigel.Visible = true;
        }

        private void butHide_Click(object sender, EventArgs e)
        {
            labBetelgeuse.Visible = false;
            labMeissa.Visible = false;
            labAlnitak.Visible = false;
            labAlnilam.Visible = false;
            labMintaka.Visible = false;
            labSaiph.Visible = false;
            labRigel.Visible = false;
        }

        private void butExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
    
}
