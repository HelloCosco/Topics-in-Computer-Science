﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Declare variables
            int workshop = 0;
            int location = 0;
            int days = 0;
            double regFee = 0.00, lodFee = 0.00, totalFee = 0.00;

  
            // Make listBox1 and 2 the workshop and location
            workshop = listBox1.SelectedIndex;
            location = listBox2.SelectedIndex;

            // Switch listBox1 with workshop 
            switch (workshop)
            {
                // Calculate numer of days and registration cost for each workshop
                case 0:
                    regFee = 1000.00;
                    days = 3;
                    break;

                case 1:
                    regFee = 800.00;
                    days = 3;
                    break;

                case 2:
                    regFee = 1500.00;
                    days = 3;
                    break;

                case 3:
                    regFee = 1300.00;
                    days = 5;
                    break;

                case 4:
                    regFee = 500.00;
                    days = 1;
                    break;
            }
            // Switch listBox2 with location
            switch (location)
            {
                //Calculate lodging cost for each location
                case 0:
                    lodFee = days * 150.00;
                    break;

                case 1:
                    lodFee = days * 225.00;
                    break;

                case 2:
                    lodFee = days * 175.00;
                    break;

                case 3:
                    lodFee = days * 300.00;
                    break;

                case 4:
                    lodFee = days * 175.00;
                    break;

                case 5:
                    lodFee = days * 150.00;
                    break;
            }

            // Calculate total fees by adding lodging fee and registration fee
            totalFee = (regFee + lodFee);

            //store double as a string
            textBox1.Text = regFee.ToString();
            textBox2.Text = lodFee.ToString();

            //Calculate total cost
            textBox3.Text = totalFee.ToString();




        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Clear Everything

            //Clear listBox1
            listBox1.ClearSelected();
            //Clear listBox2
            listBox2.ClearSelected();
            //Clear textBox1
            textBox1.Clear();
            //Clear textBox2
            textBox2.Clear();
            //Clear textBox3
            textBox3.Clear();



        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Close Workshop Selector program
            this.Close();
        }
    }
}
