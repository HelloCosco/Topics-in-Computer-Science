﻿namespace WindowsFormsApp7
{
    partial class OrionConstellation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrionConstellation));
            this.picBoxOrion = new System.Windows.Forms.PictureBox();
            this.labBetelgeuse = new System.Windows.Forms.Label();
            this.labRigel = new System.Windows.Forms.Label();
            this.labMeissa = new System.Windows.Forms.Label();
            this.labMintaka = new System.Windows.Forms.Label();
            this.labAlnilam = new System.Windows.Forms.Label();
            this.labAlnitak = new System.Windows.Forms.Label();
            this.labSaiph = new System.Windows.Forms.Label();
            this.butShow = new System.Windows.Forms.Button();
            this.butHide = new System.Windows.Forms.Button();
            this.butExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrion)).BeginInit();
            this.SuspendLayout();
            // 
            // picBoxOrion
            // 
            this.picBoxOrion.Image = ((System.Drawing.Image)(resources.GetObject("picBoxOrion.Image")));
            this.picBoxOrion.Location = new System.Drawing.Point(94, 1);
            this.picBoxOrion.Name = "picBoxOrion";
            this.picBoxOrion.Size = new System.Drawing.Size(401, 421);
            this.picBoxOrion.TabIndex = 0;
            this.picBoxOrion.TabStop = false;
            // 
            // labBetelgeuse
            // 
            this.labBetelgeuse.AutoSize = true;
            this.labBetelgeuse.Location = new System.Drawing.Point(152, 34);
            this.labBetelgeuse.Name = "labBetelgeuse";
            this.labBetelgeuse.Size = new System.Drawing.Size(60, 13);
            this.labBetelgeuse.TabIndex = 1;
            this.labBetelgeuse.Text = "Betelgeuse";
            this.labBetelgeuse.Visible = false;
            // 
            // labRigel
            // 
            this.labRigel.AutoSize = true;
            this.labRigel.Location = new System.Drawing.Point(351, 361);
            this.labRigel.Name = "labRigel";
            this.labRigel.Size = new System.Drawing.Size(31, 13);
            this.labRigel.TabIndex = 2;
            this.labRigel.Text = "Rigel";
            this.labRigel.Visible = false;
            // 
            // labMeissa
            // 
            this.labMeissa.AutoSize = true;
            this.labMeissa.Location = new System.Drawing.Point(351, 69);
            this.labMeissa.Name = "labMeissa";
            this.labMeissa.Size = new System.Drawing.Size(40, 13);
            this.labMeissa.TabIndex = 3;
            this.labMeissa.Text = "Meissa";
            this.labMeissa.Visible = false;
            // 
            // labMintaka
            // 
            this.labMintaka.AutoSize = true;
            this.labMintaka.Location = new System.Drawing.Point(327, 202);
            this.labMintaka.Name = "labMintaka";
            this.labMintaka.Size = new System.Drawing.Size(45, 13);
            this.labMintaka.TabIndex = 4;
            this.labMintaka.Text = "Mintaka";
            this.labMintaka.Visible = false;
            // 
            // labAlnilam
            // 
            this.labAlnilam.AutoSize = true;
            this.labAlnilam.Location = new System.Drawing.Point(259, 234);
            this.labAlnilam.Name = "labAlnilam";
            this.labAlnilam.Size = new System.Drawing.Size(40, 13);
            this.labAlnilam.TabIndex = 5;
            this.labAlnilam.Text = "Alnilam";
            this.labAlnilam.Visible = false;
            // 
            // labAlnitak
            // 
            this.labAlnitak.AutoSize = true;
            this.labAlnitak.Location = new System.Drawing.Point(173, 234);
            this.labAlnitak.Name = "labAlnitak";
            this.labAlnitak.Size = new System.Drawing.Size(39, 13);
            this.labAlnitak.TabIndex = 6;
            this.labAlnitak.Text = "Alnitak";
            this.labAlnitak.Visible = false;
            // 
            // labSaiph
            // 
            this.labSaiph.AutoSize = true;
            this.labSaiph.Location = new System.Drawing.Point(163, 388);
            this.labSaiph.Name = "labSaiph";
            this.labSaiph.Size = new System.Drawing.Size(34, 13);
            this.labSaiph.TabIndex = 7;
            this.labSaiph.Text = "Saiph";
            this.labSaiph.Visible = false;
            // 
            // butShow
            // 
            this.butShow.Location = new System.Drawing.Point(105, 428);
            this.butShow.Name = "butShow";
            this.butShow.Size = new System.Drawing.Size(107, 23);
            this.butShow.TabIndex = 8;
            this.butShow.Text = "Show Star Names";
            this.butShow.UseVisualStyleBackColor = true;
            this.butShow.Click += new System.EventHandler(this.butShow_Click);
            // 
            // butHide
            // 
            this.butHide.Location = new System.Drawing.Point(238, 428);
            this.butHide.Name = "butHide";
            this.butHide.Size = new System.Drawing.Size(107, 23);
            this.butHide.TabIndex = 9;
            this.butHide.Text = "Hide Star Names";
            this.butHide.UseVisualStyleBackColor = true;
            this.butHide.Click += new System.EventHandler(this.butHide_Click);
            // 
            // butExit
            // 
            this.butExit.Location = new System.Drawing.Point(374, 428);
            this.butExit.Name = "butExit";
            this.butExit.Size = new System.Drawing.Size(103, 23);
            this.butExit.TabIndex = 10;
            this.butExit.Text = "Exit";
            this.butExit.UseVisualStyleBackColor = true;
            this.butExit.Click += new System.EventHandler(this.butExit_Click);
            // 
            // OrionConstellation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.butExit);
            this.Controls.Add(this.butHide);
            this.Controls.Add(this.butShow);
            this.Controls.Add(this.labSaiph);
            this.Controls.Add(this.labAlnitak);
            this.Controls.Add(this.labAlnilam);
            this.Controls.Add(this.labMintaka);
            this.Controls.Add(this.labMeissa);
            this.Controls.Add(this.labRigel);
            this.Controls.Add(this.labBetelgeuse);
            this.Controls.Add(this.picBoxOrion);
            this.Name = "OrionConstellation";
            this.Text = "Orion Constellation";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxOrion;
        private System.Windows.Forms.Label labBetelgeuse;
        private System.Windows.Forms.Label labRigel;
        private System.Windows.Forms.Label labMeissa;
        private System.Windows.Forms.Label labMintaka;
        private System.Windows.Forms.Label labAlnilam;
        private System.Windows.Forms.Label labAlnitak;
        private System.Windows.Forms.Label labSaiph;
        private System.Windows.Forms.Button butShow;
        private System.Windows.Forms.Button butHide;
        private System.Windows.Forms.Button butExit;
    }
}

