﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace RazorPagesMovie.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new RazorPagesMovieContext(
                serviceProvider.GetRequiredService<DbContextOptions<RazorPagesMovieContext>>()))
            {
                // Look for any movies.
                if (context.Movie.Any())
                {
                    return;   // DB has been seeded
                }

                context.Movie.AddRange(
                    new Movie
                    {
                        Title = "Akira",
                        ReleaseDate = DateTime.Parse("1989-12-25"),
                        Genre = "Drama/Thriller",
                        Price = 14.99M, 
                        BoxOfficeSales = 9699620.20M,
                        Rated = "R",
                        Distribution = "International",
                        MyRatings = "5"




                    },

                    new Movie
                    {
                        Title = "Dragon Ball Z: Resurrection 'F' ",
                        ReleaseDate = DateTime.Parse("2015-5-18"),
                        Genre = "Fantasy/SciFi",
                        Price = 30.49M,
                        BoxOfficeSales = 64800000M,
                        Rated = "PG",
                        Distribution = "International",
                        MyRatings = "5"
                    },

                    new Movie
                    {
                        Title = "The Last: Naruto the Movie",
                        ReleaseDate = DateTime.Parse("2015-2-20"),
                        Genre = "Action/Romance",
                        Price = 14.96M,
                        BoxOfficeSales = 19840000M,
                        Rated = "PG",
                        Distribution = "International",
                        MyRatings = "5"
                    },

                    new Movie
                    {
                        Title = "Spirited Away",
                        ReleaseDate = DateTime.Parse("2002-9-20"),
                        Genre = "Fantasy/Mystery",
                        Price = 3.53M,
                        BoxOfficeSales = 16759504.80M,
                        Rated = "PG",
                        Distribution = "International",
                        MyRatings = "5"

                    },

                    new Movie
                    {
                        Title = "Your Name",
                        ReleaseDate = DateTime.Parse("2017-4-7"),
                        Genre = "Drama/Fantasy",
                        Price = 17.96M,
                        BoxOfficeSales = 359000000M,
                        Rated = "PG",
                        Distribution = "International",
                        MyRatings = "5"
                    },

                    new Movie
                    {
                        Title = "Howl's Moving Castle",
                        ReleaseDate = DateTime.Parse("2004-11-20"),
                        Genre = "Drama/Fantasy",
                        Price = 10.98M,
                        BoxOfficeSales = 21165235.20M,
                        Rated = "PG",
                        Distribution = "International",
                        MyRatings = "5"
                    },

                    new Movie
                    {
                        Title = "Ponyo",
                        ReleaseDate = DateTime.Parse("2008-7-19"),
                        Genre = "Drama/Fantasy",
                        Price = 12.96M,
                        BoxOfficeSales = 29986990.20M,
                        Rated = "PG",
                        Distribution = "International",
                        MyRatings = "5"
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
