﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_pName = new System.Windows.Forms.TextBox();
            this.txt_pAddress = new System.Windows.Forms.TextBox();
            this.txt_pPhoneNO = new System.Windows.Forms.TextBox();
            this.txt_cusNumber = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_pName = new System.Windows.Forms.Label();
            this.lbl_pAddress = new System.Windows.Forms.Label();
            this.lbl_pPhoneNO = new System.Windows.Forms.Label();
            this.lbl_cusNumber = new System.Windows.Forms.Label();
            this.lbl_mailing = new System.Windows.Forms.Label();
            this.btn_Create = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.chk_Mailing = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Phone Number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Customer Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(76, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Mailing:";
            // 
            // txt_pName
            // 
            this.txt_pName.Location = new System.Drawing.Point(131, 14);
            this.txt_pName.Name = "txt_pName";
            this.txt_pName.Size = new System.Drawing.Size(100, 20);
            this.txt_pName.TabIndex = 5;
            // 
            // txt_pAddress
            // 
            this.txt_pAddress.Location = new System.Drawing.Point(131, 46);
            this.txt_pAddress.Name = "txt_pAddress";
            this.txt_pAddress.Size = new System.Drawing.Size(100, 20);
            this.txt_pAddress.TabIndex = 6;
            // 
            // txt_pPhoneNO
            // 
            this.txt_pPhoneNO.Location = new System.Drawing.Point(131, 73);
            this.txt_pPhoneNO.Name = "txt_pPhoneNO";
            this.txt_pPhoneNO.Size = new System.Drawing.Size(100, 20);
            this.txt_pPhoneNO.TabIndex = 7;
            // 
            // txt_cusNumber
            // 
            this.txt_cusNumber.Location = new System.Drawing.Point(131, 104);
            this.txt_cusNumber.Name = "txt_cusNumber";
            this.txt_cusNumber.Size = new System.Drawing.Size(100, 20);
            this.txt_cusNumber.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(81, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(71, 221);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Address:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(38, 247);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Phone Number:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 278);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Customer Number:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(74, 311);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Mailling:";
            // 
            // lbl_pName
            // 
            this.lbl_pName.AutoSize = true;
            this.lbl_pName.Location = new System.Drawing.Point(128, 192);
            this.lbl_pName.Name = "lbl_pName";
            this.lbl_pName.Size = new System.Drawing.Size(0, 13);
            this.lbl_pName.TabIndex = 15;
            // 
            // lbl_pAddress
            // 
            this.lbl_pAddress.AutoSize = true;
            this.lbl_pAddress.Location = new System.Drawing.Point(128, 221);
            this.lbl_pAddress.Name = "lbl_pAddress";
            this.lbl_pAddress.Size = new System.Drawing.Size(0, 13);
            this.lbl_pAddress.TabIndex = 16;
            // 
            // lbl_pPhoneNO
            // 
            this.lbl_pPhoneNO.AutoSize = true;
            this.lbl_pPhoneNO.Location = new System.Drawing.Point(128, 247);
            this.lbl_pPhoneNO.Name = "lbl_pPhoneNO";
            this.lbl_pPhoneNO.Size = new System.Drawing.Size(0, 13);
            this.lbl_pPhoneNO.TabIndex = 17;
            // 
            // lbl_cusNumber
            // 
            this.lbl_cusNumber.AutoSize = true;
            this.lbl_cusNumber.Location = new System.Drawing.Point(128, 278);
            this.lbl_cusNumber.Name = "lbl_cusNumber";
            this.lbl_cusNumber.Size = new System.Drawing.Size(0, 13);
            this.lbl_cusNumber.TabIndex = 18;
            // 
            // lbl_mailing
            // 
            this.lbl_mailing.AutoSize = true;
            this.lbl_mailing.Location = new System.Drawing.Point(128, 311);
            this.lbl_mailing.Name = "lbl_mailing";
            this.lbl_mailing.Size = new System.Drawing.Size(0, 13);
            this.lbl_mailing.TabIndex = 19;
            // 
            // btn_Create
            // 
            this.btn_Create.Location = new System.Drawing.Point(12, 349);
            this.btn_Create.Name = "btn_Create";
            this.btn_Create.Size = new System.Drawing.Size(74, 38);
            this.btn_Create.TabIndex = 20;
            this.btn_Create.Text = "Create";
            this.btn_Create.UseVisualStyleBackColor = true;
            this.btn_Create.Click += new System.EventHandler(this.btn_Create_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(79, 403);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 28);
            this.btn_Exit.TabIndex = 21;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // chk_Mailing
            // 
            this.chk_Mailing.AutoSize = true;
            this.chk_Mailing.Location = new System.Drawing.Point(131, 130);
            this.chk_Mailing.Name = "chk_Mailing";
            this.chk_Mailing.Size = new System.Drawing.Size(80, 17);
            this.chk_Mailing.TabIndex = 22;
            this.chk_Mailing.Text = "checkBox1";
            this.chk_Mailing.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(158, 349);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 38);
            this.button1.TabIndex = 23;
            this.button1.Text = "Discount Form";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 430);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chk_Mailing);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Create);
            this.Controls.Add(this.lbl_mailing);
            this.Controls.Add(this.lbl_cusNumber);
            this.Controls.Add(this.lbl_pPhoneNO);
            this.Controls.Add(this.lbl_pAddress);
            this.Controls.Add(this.lbl_pName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_cusNumber);
            this.Controls.Add(this.txt_pPhoneNO);
            this.Controls.Add(this.txt_pAddress);
            this.Controls.Add(this.txt_pName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Preferred Customer Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_pName;
        private System.Windows.Forms.TextBox txt_pAddress;
        private System.Windows.Forms.TextBox txt_pPhoneNO;
        private System.Windows.Forms.TextBox txt_cusNumber;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_pName;
        private System.Windows.Forms.Label lbl_pAddress;
        private System.Windows.Forms.Label lbl_pPhoneNO;
        private System.Windows.Forms.Label lbl_cusNumber;
        private System.Windows.Forms.Label lbl_mailing;
        private System.Windows.Forms.Button btn_Create;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.CheckBox chk_Mailing;
        private System.Windows.Forms.Button button1;
    }
}

